"""
Kalshi (API) Plugin — Type A REST API + WebSocket.

CFTC-regulated prediction market exchange.
Coexists with existing Kalshi CDP (browser) plugin — user chooses API or browser.

Production: https://api.elections.kalshi.com/trade-api/v2
Demo:       https://demo-api.kalshi.co/trade-api/v2
"""

import os
import sys
import json
import time
import base64
import logging
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

# Ensure UTF-8 stdout (Windows cp949 fix)
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

import asyncio

import httpx

from core.plugin_api import BrokerPlugin, PluginMetadata
from core.models import AccountInfo, PortfolioItem

# Package-qualified imports (avoids sys.modules conflict between plugins)
from plugins.kalshi_api.modules.markets import (
    get_markets,
    get_market_detail,
    get_orderbook,
    get_events,
    get_event_detail,
    get_trades,
    get_candlesticks,
    get_tickers_for_market,
    get_batch_prices,
    CATEGORY_API_MAP,
    # Phase 2B
    get_event_metadata,
    get_event_candlesticks,
    get_forecast_percentiles,
    get_multivariate_events,
    get_historical_candlesticks,
    get_sports_filters,
)
from plugins.kalshi_api.modules.trading import (
    get_balance,
    get_positions,
    get_fills,
    get_settlements,
    place_order,
    cancel_order,
    get_orders,
    amend_order,
    decrease_order,
    batch_create_orders,
    batch_cancel_orders,
    get_historical_cutoff,
    get_historical_markets,
    get_historical_market_detail,
    get_historical_fills,
    get_historical_orders,
    # Phase 2B
    get_queue_position,
    get_queue_positions,
    get_resting_order_value,
)
from plugins.kalshi_api.modules.exchange import (
    get_exchange_status,
    get_exchange_schedule,
    get_exchange_announcements,
    get_fee_changes,
    get_user_data_timestamp,
    get_account_limits,
)
from plugins.kalshi_api.modules.websocket import KalshiWebSocket

_PLUGIN_DIR = Path(__file__).parent

logger = logging.getLogger("kalshi_api")

# Default base URLs
_DEFAULT_DEMO_URL = "https://demo-api.kalshi.co/trade-api/v2"
_DEFAULT_PROD_URL = "https://api.elections.kalshi.com/trade-api/v2"
_WS_DEMO_URL = "wss://demo-api.kalshi.co/trade-api/ws/v2"
_WS_PROD_URL = "wss://api.elections.kalshi.com/trade-api/ws/v2"


class TokenBucketRateLimiter:
    """Thread-safe token bucket rate limiter."""

    def __init__(self, rate: float = 15.0, burst: int = 15):
        self._rate = rate
        self._burst = burst
        self._tokens = float(burst)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self, timeout: float = 15.0) -> bool:
        deadline = time.monotonic() + timeout
        while True:
            with self._lock:
                now = time.monotonic()
                elapsed = now - self._last_refill
                self._tokens = min(self._burst, self._tokens + elapsed * self._rate)
                self._last_refill = now
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return True
            if time.monotonic() >= deadline:
                return False
            time.sleep(0.05)


class KalshiAPIPlugin(BrokerPlugin):
    """Kalshi Prediction Market — REST API plugin."""

    def __init__(self):
        self._connected = False
        self._api_key_id: Optional[str] = None
        self._private_key = None  # RSA private key object
        self._base_url = _DEFAULT_DEMO_URL
        self._ws_url = _WS_DEMO_URL
        self._engine_config = self._load_engine_config()
        self._rate_limiter = TokenBucketRateLimiter(
            rate=self._engine_config.get("rate_limits", {}).get("global_calls_per_sec", 15.0),
            burst=self._engine_config.get("rate_limits", {}).get("global_burst", 15),
        )
        self._cache: Dict[str, tuple] = {}  # ticker -> (data, timestamp)
        self._cache_ttl = 5.0
        self._batch_size = self._engine_config.get("polling", {}).get("batch_size", 100)
        self._websocket: Optional[KalshiWebSocket] = None
        self._ws_price_cache: Dict[str, Dict[str, Any]] = {}  # ticker -> price data
        self._settings_manager = None

    # -----------------------------------------------------------------------
    # PluginMetadata (required by ABC)
    # -----------------------------------------------------------------------

    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            id="kalshi_api",
            name="Kalshi (API)",
            version="1.0.0",
            author="SandClaw Team",
            description="Kalshi Prediction Market — CFTC-regulated YES/NO contract trading via REST API",
            plugin_type="api",
            region="US",
            asset_classes=["PREDICTION"],
            symbol_example="KXBTCD-26MAR14-B59500",
            markets=[
                "kalshi_all", "kalshi_crypto", "kalshi_economics", "kalshi_politics",
                "kalshi_elections", "kalshi_climate", "kalshi_sports", "kalshi_entertainment",
                "kalshi_tech", "kalshi_financials", "kalshi_companies", "kalshi_mentions",
                "kalshi_social", "kalshi_world", "kalshi_top_volume", "kalshi_closing_soon",
            ],
            is_base=True,
            strategy_mode="chatbot",
        )

    # -----------------------------------------------------------------------
    # Connection (required by ABC)
    # -----------------------------------------------------------------------

    def connect(self) -> bool:
        """Load RSA key + verify connection via GET /exchange/status."""
        try:
            from core.key_manager import KeyManager
            keys = KeyManager.get_keys('kalshi_api')

            if not keys:
                logger.error("No credentials found for kalshi_api")
                return False

            self._api_key_id = keys.get("api_key_id", "")
            pem_str = keys.get("private_key_pem", "")
            base_url = keys.get("base_url", "").strip()

            if not self._api_key_id or not pem_str:
                logger.error("API Key ID and Private Key PEM are required")
                return False

            # Normalize PEM key: auto-wrap bare base64, fix line endings
            pem_str = self._normalize_pem(pem_str)

            # Load RSA private key
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.backends import default_backend

            pem_bytes = pem_str.encode("utf-8")
            self._private_key = serialization.load_pem_private_key(
                pem_bytes, password=None, backend=default_backend()
            )

            # Set base URL (demo vs prod)
            if base_url:
                self._base_url = base_url
            else:
                self._base_url = _DEFAULT_DEMO_URL

            # Determine WebSocket URL
            if "demo" in self._base_url:
                self._ws_url = _WS_DEMO_URL
            else:
                self._ws_url = _WS_PROD_URL

            # Verify connection
            result = self._api_call("GET", "/exchange/status")
            if "error" in result:
                logger.error(f"Connection check failed: {result['error']}")
                return False

            self._connected = True
            logger.info(
                f"Connected to Kalshi API "
                f"({'DEMO' if 'demo' in self._base_url else 'PRODUCTION'})"
            )
            return True

        except Exception as e:
            logger.error(f"Connection failed: {e}")
            return False

    @staticmethod
    def _normalize_pem(pem_str: str) -> str:
        """
        Normalize PEM key string:
        - Fix \\r\\n → \\n line endings
        - Auto-wrap bare base64 with RSA/PKCS8 PEM headers
        - Re-wrap base64 to 64-char lines if needed
        """
        import re
        # Normalize line endings
        pem_str = pem_str.strip().replace("\r\n", "\n").replace("\r", "\n")

        # Already has proper PEM framing
        if pem_str.startswith("-----BEGIN"):
            return pem_str

        # Strip any accidental PEM-like partial headers
        pem_str = re.sub(r"-----\s*(BEGIN|END)\s+[A-Z\s]*-----", "", pem_str)

        # Remove all whitespace to get clean base64
        clean_b64 = re.sub(r"\s+", "", pem_str)

        # Re-wrap to 64-char lines (PEM standard)
        lines = [clean_b64[i:i+64] for i in range(0, len(clean_b64), 64)]

        # Kalshi uses RSA keys (PKCS#1 format)
        return (
            "-----BEGIN RSA PRIVATE KEY-----\n"
            + "\n".join(lines)
            + "\n-----END RSA PRIVATE KEY-----\n"
        )

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def batch_size(self) -> int:
        """Batch size for TradingLoop chunk processing."""
        return self._batch_size

    @property
    def batch_delay(self) -> float:
        """Delay between batch chunks for TradingLoop."""
        return self._engine_config.get("polling", {}).get("batch_delay", 0.0)

    def check_health(self) -> bool:
        """Lightweight health check."""
        if not self._connected:
            return False
        result = self._api_call("GET", "/exchange/status")
        return "error" not in result

    def disconnect(self):
        """Clean up connections."""
        self.stop_websocket()
        self._connected = False
        self._private_key = None
        self._cache.clear()
        self._ws_price_cache.clear()
        logger.info("Disconnected from Kalshi API")

    # -----------------------------------------------------------------------
    # Account & Portfolio (required by ABC)
    # -----------------------------------------------------------------------

    def get_account_info(self) -> AccountInfo:
        result = get_balance(self._api_call)
        if "error" in result:
            return AccountInfo(
                total_balance=0, cash_balance=0,
                unrealized_pnl=0, pnl_rate=0,
                currency="USD",
            )
        balance_usd = result.get("balance_dollars", 0)
        portfolio_usd = result.get("portfolio_value_dollars", 0)
        return AccountInfo(
            total_balance=balance_usd + portfolio_usd,
            cash_balance=balance_usd,
            unrealized_pnl=portfolio_usd,
            pnl_rate=0,
            currency="USD",
        )

    def get_portfolio(self) -> List[PortfolioItem]:
        result = get_positions(self._api_call)
        if "error" in result:
            return []
        items = []
        for pos in result.get("positions", []):
            position_val = pos.get("position", 0)
            side = "YES" if position_val > 0 else "NO"
            items.append(
                PortfolioItem(
                    symbol=pos.get("ticker", ""),
                    name=f"{pos.get('ticker', '')} ({side})",
                    quantity=abs(position_val),
                    avg_price=0,
                    current_price=0,
                    pnl_rate=0,
                    pnl_amount=float(pos.get("realized_pnl_dollars", 0)),
                )
            )
        return items

    def _is_margin_enabled(self) -> bool:
        """Kalshi does not support margin trading."""
        return False

    # -----------------------------------------------------------------------
    # Trading (required by ABC)
    # -----------------------------------------------------------------------

    def buy_order(self, symbol: str, quantity: float, **kwargs) -> Dict[str, Any]:
        """Place a BUY order. Defaults to YES side."""
        side = kwargs.get("side", "yes")
        price = kwargs.get("price")
        price_dollars = kwargs.get("yes_price_dollars", price)
        time_in_force = kwargs.get("time_in_force")

        return place_order(
            self._api_call,
            ticker=symbol,
            side=side,
            action="buy",
            count_fp=f"{int(quantity):.2f}" if quantity else None,
            yes_price_dollars=str(price_dollars) if price_dollars else None,
            time_in_force=time_in_force,
        )

    def sell_order(self, symbol: str, quantity: float, **kwargs) -> Dict[str, Any]:
        """Place a SELL order."""
        side = kwargs.get("side", "yes")
        price = kwargs.get("price")
        price_dollars = kwargs.get("yes_price_dollars", price)

        return place_order(
            self._api_call,
            ticker=symbol,
            side=side,
            action="sell",
            count_fp=f"{int(quantity):.2f}" if quantity else None,
            yes_price_dollars=str(price_dollars) if price_dollars else None,
        )

    # -----------------------------------------------------------------------
    # Price Data (engine support)
    # -----------------------------------------------------------------------

    def get_price(self, symbol: str) -> Dict[str, Any]:
        """Get single market price (with cache)."""
        # Check WebSocket cache first
        if symbol in self._ws_price_cache:
            return self._ws_price_cache[symbol]

        # Check REST cache
        cached = self._cache.get(symbol)
        if cached:
            data, ts = cached
            if time.time() - ts < self._cache_ttl:
                return data

        # Fetch from REST API
        result = get_market_detail(self._api_call, symbol)
        if "error" not in result:
            self._cache[symbol] = (result, time.time())
        return result

    def get_current_prices(self, symbols: List[str]) -> Dict[str, float]:
        """Batch price lookup via GET /markets?tickers=A,B,C.

        Single API call per 100 tickers (vs. N individual calls).
        Returns {ticker: last_price_float}.
        """
        if not symbols:
            return {}

        batch = get_batch_prices(
            self._api_call,
            symbols,
            chunk_size=self._batch_size,
        )

        prices = {}
        for ticker, data in batch.items():
            try:
                prices[ticker] = float(data.get("last_price", 0))
            except (ValueError, TypeError):
                prices[ticker] = 0.0

        # Update cache for individual lookups
        now = time.time()
        for ticker, data in batch.items():
            self._cache[ticker] = (data, now)

        return prices

    async def get_ohlcv(self, symbol: str, interval: str = "day",
                        count: int = 200) -> Any:
        """Get OHLCV data (candlesticks) — async wrapper."""
        try:
            result = await asyncio.to_thread(
                self._get_ohlcv_sync, symbol, interval, count
            )
            return result
        except Exception as e:
            logger.error(f"get_ohlcv failed for {symbol}: {e}")
            return None

    def _get_ohlcv_sync(self, symbol: str, interval: str = "day",
                        count: int = 200) -> Any:
        """Synchronous OHLCV via Kalshi candlesticks API."""
        # Extract series_ticker from market ticker (e.g. KXBTCD from KXBTCD-26MAR14-B59500)
        parts = symbol.split("-")
        if len(parts) < 2:
            return None

        series_ticker = parts[0]
        period_map = {"1m": 1, "1h": 60, "day": 1440, "1d": 1440}
        period_interval = period_map.get(interval, 1440)

        return get_candlesticks(self._api_call, series_ticker, symbol, period_interval)

    def get_all_tickers(self, market: str = None) -> List[str]:
        """
        Get all tickers for a market category.
        Called by engine in REST API polling mode.
        Returns List[str] — list of ticker strings.
        """
        if market is None:
            market = "kalshi_all"
        raw_markets = get_tickers_for_market(self._api_call, market)
        return [m.get("ticker", "") for m in raw_markets if m.get("ticker")]

    # -----------------------------------------------------------------------
    # WebSocket
    # -----------------------------------------------------------------------

    def start_websocket(self) -> bool:
        """Start WebSocket for real-time price updates."""
        if self._websocket and self._websocket.is_connected:
            return True

        if not self._private_key or not self._api_key_id:
            logger.error("Cannot start WebSocket: no credentials")
            return False

        self._websocket = KalshiWebSocket(
            ws_url=self._ws_url,
            api_key_id=self._api_key_id,
            private_key=self._private_key,
            on_ticker=self._on_ws_ticker,
            on_trade=self._on_ws_trade,
            on_fill=self._on_ws_fill,
        )
        return self._websocket.start()

    def stop_websocket(self):
        """Stop WebSocket connection."""
        if self._websocket:
            self._websocket.stop()
            self._websocket = None
        self._ws_price_cache.clear()

    def _on_ws_ticker(self, data: Dict[str, Any]):
        """Handle incoming ticker update from WebSocket."""
        ticker = data.get("ticker", "")
        if ticker:
            self._ws_price_cache[ticker] = data

    def _on_ws_trade(self, data: Dict[str, Any]):
        """Handle trade event from WebSocket."""
        ticker = data.get("ticker", "")
        if ticker:
            # Update price cache from trade data
            cached = self._ws_price_cache.get(ticker, {})
            cached["last_price"] = data.get("yes_price", cached.get("last_price", ""))
            cached["ticker"] = ticker
            self._ws_price_cache[ticker] = cached

    def _on_ws_fill(self, data: Dict[str, Any]):
        """Handle fill notification from WebSocket."""
        logger.info(
            f"Fill: {data.get('ticker')} {data.get('side')} "
            f"{data.get('action')} {data.get('count')} @ {data.get('yes_price')}"
        )

    # -----------------------------------------------------------------------
    # AI Tools
    # -----------------------------------------------------------------------

    def get_ai_system_prompt(self) -> str:
        """Load system prompt for AI chatbot."""
        prompt_path = _PLUGIN_DIR / "system_prompt.txt"
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        return "Kalshi API plugin for prediction market trading."

    def get_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_markets",
                    "description": (
                        "[USE THIS WHEN] user wants to browse or search prediction markets "
                        "[DO NOT USE THIS WHEN] user asks about a specific ticker (use get_market_detail). "
                        "List prediction markets with optional filters. "
                        "Returns market tickers, titles, prices, volume."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "category": {
                                "type": "string",
                                "description": "Category filter: crypto, economics, politics, weather, sports, tech, finance",
                                "enum": ["crypto", "economics", "politics", "weather", "sports", "tech", "finance"],
                            },
                            "status": {
                                "type": "string",
                                "description": "Market status filter",
                                "enum": ["open", "closed", "settled"],
                                "default": "open",
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Max results (1-200)",
                                "default": 20,
                            },
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_market_detail",
                    "description": (
                        "[USE THIS WHEN] user asks about a specific market or ticker "
                        "Get detailed info for a single market including rules, prices, and status."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {
                                "type": "string",
                                "description": "Market ticker (e.g. KXBTCD-26MAR14-B59500)",
                            },
                        },
                        "required": ["ticker"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_orderbook",
                    "description": (
                        "[USE THIS WHEN] user wants to see bid/ask depth "
                        "View YES/NO orderbook for a specific market."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {
                                "type": "string",
                                "description": "Market ticker",
                            },
                            "depth": {
                                "type": "integer",
                                "description": "Orderbook depth (0=all, 1-100)",
                                "default": 10,
                            },
                        },
                        "required": ["ticker"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_balance",
                    "description": (
                        "[USE THIS WHEN] user asks about Kalshi account balance or buying power "
                        "[DO NOT USE THIS WHEN] user asks for other broker balances. "
                        "Get account balance and portfolio value in USD."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {},
                        "required": [],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_positions",
                    "description": (
                        "[USE THIS WHEN] user asks about Kalshi current positions or P&L "
                        "List current positions with realized P&L."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {
                                "type": "string",
                                "description": "Filter by market ticker (optional)",
                            },
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_place_order",
                    "description": (
                        "[USE THIS WHEN] user wants to buy or sell a Kalshi prediction contract "
                        "Place a YES/NO order. ALWAYS confirm with user before placing. "
                        "Orders are limit only. Use buy_max_cost for market-like fills."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {"type": "string", "description": "Market ticker"},
                            "side": {"type": "string", "enum": ["yes", "no"], "description": "YES or NO"},
                            "action": {"type": "string", "enum": ["buy", "sell"], "description": "Buy or sell"},
                            "count": {"type": "integer", "description": "Number of contracts"},
                            "yes_price_dollars": {"type": "string", "description": "Limit price (e.g. '0.48')"},
                            "time_in_force": {
                                "type": "string",
                                "enum": ["good_till_canceled", "fill_or_kill", "immediate_or_cancel"],
                                "default": "good_till_canceled",
                            },
                        },
                        "required": ["ticker", "side", "action", "count"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_cancel_order",
                    "description": (
                        "[USE THIS WHEN] user wants to cancel an open Kalshi order "
                        "Cancel an open order by order ID."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "order_id": {"type": "string", "description": "Order ID to cancel"},
                        },
                        "required": ["order_id"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_orders",
                    "description": (
                        "[USE THIS WHEN] user asks about open or filled Kalshi orders "
                        "List orders with optional status filter."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "status": {
                                "type": "string",
                                "enum": ["resting", "canceled", "executed"],
                                "description": "Filter by order status",
                            },
                            "ticker": {"type": "string", "description": "Filter by market ticker"},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_trades",
                    "description": (
                        "[USE THIS WHEN] user wants to see recent Kalshi trade history "
                        "View recent trades for a market."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {"type": "string", "description": "Market ticker"},
                            "limit": {"type": "integer", "description": "Max results", "default": 20},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_events",
                    "description": (
                        "[USE THIS WHEN] user wants to browse Kalshi event categories "
                        "Browse events (collections of markets)."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "series_ticker": {"type": "string", "description": "Filter by series (e.g. KXBTC)"},
                            "status": {"type": "string", "enum": ["open", "closed", "settled"], "default": "open"},
                            "limit": {"type": "integer", "description": "Max results", "default": 20},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_event_detail",
                    "description": (
                        "[USE THIS WHEN] user asks about a specific Kalshi event "
                        "Get event details with nested markets."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "event_ticker": {"type": "string", "description": "Event ticker (e.g. KXBTCD-26MAR14)"},
                        },
                        "required": ["event_ticker"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_fills",
                    "description": (
                        "[USE THIS WHEN] user asks about Kalshi fill history or trade executions "
                        "List fills (executed trades) for the account."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {"type": "string", "description": "Filter by market ticker (optional)"},
                            "order_id": {"type": "string", "description": "Filter by order ID (optional)"},
                            "limit": {"type": "integer", "description": "Max results", "default": 50},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_settlements",
                    "description": (
                        "[USE THIS WHEN] user asks about Kalshi settlement history "
                        "List settled contracts and payouts."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "limit": {"type": "integer", "description": "Max results", "default": 50},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_candlesticks",
                    "description": (
                        "[USE THIS WHEN] user wants OHLC chart data for a Kalshi market "
                        "Get candlestick (OHLC) data for a market."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "series_ticker": {"type": "string", "description": "Series ticker (e.g. KXBTCD)"},
                            "ticker": {"type": "string", "description": "Market ticker (e.g. KXBTCD-26MAR14-B59500)"},
                            "period_interval": {
                                "type": "integer",
                                "description": "Interval in minutes: 1 (1min), 60 (1hr), 1440 (1day)",
                                "default": 60,
                            },
                        },
                        "required": ["series_ticker", "ticker"],
                    },
                },
            },
            # --- Phase 2A: Order management ---
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_amend_order",
                    "description": (
                        "[USE THIS WHEN] user wants to change price or quantity of an existing order "
                        "Amend order price/quantity. Retains queue position if only reducing."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "order_id": {"type": "string", "description": "Order ID to amend"},
                            "ticker": {"type": "string", "description": "Market ticker"},
                            "side": {"type": "string", "enum": ["yes", "no"]},
                            "action": {"type": "string", "enum": ["buy", "sell"]},
                            "count": {"type": "integer", "description": "New total contract count"},
                            "yes_price_dollars": {"type": "string", "description": "New YES price (e.g. '0.55')"},
                        },
                        "required": ["order_id", "ticker", "side", "action"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_decrease_order",
                    "description": (
                        "[USE THIS WHEN] user wants to reduce order quantity without losing queue position "
                        "Decrease order quantity. Keeps queue priority."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "order_id": {"type": "string", "description": "Order ID to decrease"},
                            "reduce_by": {"type": "integer", "description": "Reduce BY this many contracts"},
                            "reduce_to": {"type": "integer", "description": "Reduce TO this many contracts"},
                        },
                        "required": ["order_id"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_batch_create_orders",
                    "description": (
                        "[USE THIS WHEN] user wants to place multiple orders at once "
                        "Create up to 20 orders in a single request."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "orders": {
                                "type": "array",
                                "description": "Array of order objects (max 20). Each: {ticker, side, action, count, yes_price_dollars}",
                                "items": {"type": "object"},
                            },
                        },
                        "required": ["orders"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_batch_cancel_orders",
                    "description": (
                        "[USE THIS WHEN] user wants to cancel multiple orders at once "
                        "Cancel up to 20 orders in a single request."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "order_ids": {
                                "type": "array",
                                "description": "Array of order IDs to cancel (max 20)",
                                "items": {"type": "string"},
                            },
                        },
                        "required": ["order_ids"],
                    },
                },
            },
            # --- Phase 2A: Historical data ---
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_historical_cutoff",
                    "description": (
                        "[USE THIS WHEN] user asks about data availability cutoff dates "
                        "Get timestamps separating live vs archived data."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_historical_markets",
                    "description": (
                        "[USE THIS WHEN] user asks about old/settled/archived markets "
                        "List settled markets older than live cutoff."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "limit": {"type": "integer", "description": "Max results", "default": 50},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_historical_market_detail",
                    "description": (
                        "[USE THIS WHEN] user asks about a specific old/archived market "
                        "Get details for a single archived market."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {"type": "string", "description": "Market ticker"},
                        },
                        "required": ["ticker"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_historical_fills",
                    "description": (
                        "[USE THIS WHEN] user asks about old fill/trade history "
                        "Get fills from before historical cutoff."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {"type": "string", "description": "Filter by market ticker"},
                            "limit": {"type": "integer", "description": "Max results", "default": 50},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_historical_orders",
                    "description": (
                        "[USE THIS WHEN] user asks about old order history "
                        "Get canceled/executed orders from before historical cutoff."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {"type": "string", "description": "Filter by market ticker"},
                            "status": {"type": "string", "enum": ["canceled", "executed"]},
                            "limit": {"type": "integer", "description": "Max results", "default": 50},
                        },
                    },
                },
            },
            # --- Phase 2B: Exchange Info ---
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_exchange_status",
                    "description": (
                        "[USE THIS WHEN] user asks if Kalshi exchange is open or operational "
                        "Get exchange status: trading active, exchange active, estimated resume time."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_exchange_schedule",
                    "description": (
                        "[USE THIS WHEN] user asks about Kalshi trading hours or maintenance "
                        "Get weekly trading schedule (ET) and planned maintenance windows."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_exchange_announcements",
                    "description": (
                        "[USE THIS WHEN] user asks about Kalshi announcements or notices "
                        "Get exchange-wide announcements (info, warning, error)."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_fee_changes",
                    "description": (
                        "[USE THIS WHEN] user asks about Kalshi fee schedule or fee changes "
                        "Get series fee change records."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "series_ticker": {"type": "string", "description": "Filter by series ticker (optional)"},
                            "show_historical": {"type": "boolean", "description": "Include past fee changes", "default": False},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_user_data_timestamp",
                    "description": (
                        "[USE THIS WHEN] user asks when their Kalshi data was last updated "
                        "Get the timestamp when balance, orders, fills, positions data was last validated."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_account_limits",
                    "description": (
                        "[USE THIS WHEN] user asks about API rate limits or their API tier "
                        "Get API tier and rate limit information for the authenticated account."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            # --- Phase 2B: Queue Position ---
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_queue_position",
                    "description": (
                        "[USE THIS WHEN] user asks about their order's position in the queue "
                        "Get queue position for a single resting order."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "order_id": {"type": "string", "description": "Order ID"},
                        },
                        "required": ["order_id"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_queue_positions",
                    "description": (
                        "[USE THIS WHEN] user asks about queue positions for multiple orders "
                        "Get queue positions for all resting orders, optionally filtered."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "market_tickers": {"type": "string", "description": "Comma-separated market tickers to filter"},
                            "event_ticker": {"type": "string", "description": "Event ticker to filter"},
                        },
                    },
                },
            },
            # --- Phase 2B: Events Enhancement ---
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_event_metadata",
                    "description": (
                        "[USE THIS WHEN] user asks about event images, settlement sources, or metadata "
                        "Get event metadata: images, market colors, settlement sources."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "event_ticker": {"type": "string", "description": "Event ticker"},
                        },
                        "required": ["event_ticker"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_event_candlesticks",
                    "description": (
                        "[USE THIS WHEN] user wants OHLC chart data aggregated for a Kalshi event "
                        "Get event-level candlestick data (aggregated across all markets in the event)."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "series_ticker": {"type": "string", "description": "Series ticker"},
                            "event_ticker": {"type": "string", "description": "Event ticker"},
                            "start_ts": {"type": "integer", "description": "Start unix timestamp"},
                            "end_ts": {"type": "integer", "description": "End unix timestamp"},
                            "period_interval": {
                                "type": "integer",
                                "description": "Interval: 1 (1min), 60 (1hr), 1440 (1day)",
                                "default": 60,
                            },
                        },
                        "required": ["series_ticker", "event_ticker", "start_ts", "end_ts"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_forecast_percentiles",
                    "description": (
                        "[USE THIS WHEN] user asks about event forecast or probability distribution history "
                        "Get forecast percentile history for an event (e.g. median, P10, P90)."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "series_ticker": {"type": "string", "description": "Series ticker"},
                            "event_ticker": {"type": "string", "description": "Event ticker"},
                            "percentiles": {
                                "type": "array",
                                "items": {"type": "integer"},
                                "description": "Percentile values (0-10000, max 10). E.g. [1000, 5000, 9000] for P10/P50/P90",
                            },
                            "start_ts": {"type": "integer", "description": "Start unix timestamp"},
                            "end_ts": {"type": "integer", "description": "End unix timestamp"},
                            "period_interval": {
                                "type": "integer",
                                "description": "Period: 0, 1, 60, or 1440 minutes",
                                "default": 60,
                            },
                        },
                        "required": ["series_ticker", "event_ticker", "percentiles", "start_ts", "end_ts"],
                    },
                },
            },
            # --- Phase 2B: Advanced Market Data ---
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_multivariate_events",
                    "description": (
                        "[USE THIS WHEN] user asks about multivariate or multi-outcome events "
                        "List multivariate events (multiple interrelated outcome markets)."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "series_ticker": {"type": "string", "description": "Filter by series ticker"},
                            "collection_ticker": {"type": "string", "description": "Filter by collection ticker"},
                            "with_nested_markets": {"type": "boolean", "description": "Include nested market details", "default": False},
                            "limit": {"type": "integer", "description": "Max results", "default": 20},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_historical_candlesticks",
                    "description": (
                        "[USE THIS WHEN] user wants chart data for a settled/archived market "
                        "Get OHLC candlestick data for markets older than the live cutoff."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "ticker": {"type": "string", "description": "Market ticker"},
                            "start_ts": {"type": "integer", "description": "Start unix timestamp"},
                            "end_ts": {"type": "integer", "description": "End unix timestamp"},
                            "period_interval": {
                                "type": "integer",
                                "description": "Interval: 1 (1min), 60 (1hr), 1440 (1day)",
                                "default": 60,
                            },
                        },
                        "required": ["ticker", "start_ts", "end_ts"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_sports_filters",
                    "description": (
                        "[USE THIS WHEN] user asks about available sports categories or leagues "
                        "Get available sports filters: sports, scopes, and competitions."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            # --- Phase 2B: Portfolio Enhancement ---
            {
                "type": "function",
                "function": {
                    "name": "kalshi_api_get_resting_order_value",
                    "description": (
                        "[USE THIS WHEN] user asks about total value of open/resting orders "
                        "Get the total value of all resting (open) orders."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
        ]

    def execute_tool(self, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch tool call to handler."""
        handlers = {
            "kalshi_api_get_markets": self._tool_get_markets,
            "kalshi_api_get_market_detail": self._tool_get_market_detail,
            "kalshi_api_get_orderbook": self._tool_get_orderbook,
            "kalshi_api_get_balance": self._tool_get_balance,
            "kalshi_api_get_positions": self._tool_get_positions,
            "kalshi_api_place_order": self._tool_place_order,
            "kalshi_api_cancel_order": self._tool_cancel_order,
            "kalshi_api_get_orders": self._tool_get_orders,
            "kalshi_api_get_trades": self._tool_get_trades,
            "kalshi_api_get_events": self._tool_get_events,
            "kalshi_api_get_event_detail": self._tool_get_event_detail,
            "kalshi_api_get_fills": self._tool_get_fills,
            "kalshi_api_get_settlements": self._tool_get_settlements,
            "kalshi_api_get_candlesticks": self._tool_get_candlesticks,
            "kalshi_api_amend_order": self._tool_amend_order,
            "kalshi_api_decrease_order": self._tool_decrease_order,
            "kalshi_api_batch_create_orders": self._tool_batch_create_orders,
            "kalshi_api_batch_cancel_orders": self._tool_batch_cancel_orders,
            "kalshi_api_get_historical_cutoff": self._tool_get_historical_cutoff,
            "kalshi_api_get_historical_markets": self._tool_get_historical_markets,
            "kalshi_api_get_historical_market_detail": self._tool_get_historical_market_detail,
            "kalshi_api_get_historical_fills": self._tool_get_historical_fills,
            "kalshi_api_get_historical_orders": self._tool_get_historical_orders,
            # Phase 2B
            "kalshi_api_get_exchange_status": self._tool_get_exchange_status,
            "kalshi_api_get_exchange_schedule": self._tool_get_exchange_schedule,
            "kalshi_api_get_exchange_announcements": self._tool_get_exchange_announcements,
            "kalshi_api_get_fee_changes": self._tool_get_fee_changes,
            "kalshi_api_get_user_data_timestamp": self._tool_get_user_data_timestamp,
            "kalshi_api_get_account_limits": self._tool_get_account_limits,
            "kalshi_api_get_queue_position": self._tool_get_queue_position,
            "kalshi_api_get_queue_positions": self._tool_get_queue_positions,
            "kalshi_api_get_event_metadata": self._tool_get_event_metadata,
            "kalshi_api_get_event_candlesticks": self._tool_get_event_candlesticks,
            "kalshi_api_get_forecast_percentiles": self._tool_get_forecast_percentiles,
            "kalshi_api_get_multivariate_events": self._tool_get_multivariate_events,
            "kalshi_api_get_historical_candlesticks": self._tool_get_historical_candlesticks,
            "kalshi_api_get_sports_filters": self._tool_get_sports_filters,
            "kalshi_api_get_resting_order_value": self._tool_get_resting_order_value,
        }
        handler = handlers.get(tool_name)
        if not handler:
            return {"error": f"Unknown tool: {tool_name}"}
        try:
            return handler(args)
        except Exception as e:
            logger.error(f"execute_tool({tool_name}) failed: {e}")
            return {"error": str(e)}

    # -----------------------------------------------------------------------
    # Tool handlers
    # -----------------------------------------------------------------------

    def _tool_get_markets(self, args: dict) -> Dict[str, Any]:
        category = args.get("category")
        status = args.get("status", "open")
        limit = args.get("limit", 20)

        if category:
            market_key = f"kalshi_{category}"
            tickers = get_tickers_for_market(self._api_call, market_key)
            return {"markets": tickers[:limit], "count": len(tickers[:limit])}

        return get_markets(self._api_call, limit=limit, status=status)

    def _tool_get_market_detail(self, args: dict) -> Dict[str, Any]:
        return get_market_detail(self._api_call, args.get("ticker", ""))

    def _tool_get_orderbook(self, args: dict) -> Dict[str, Any]:
        return get_orderbook(
            self._api_call, args.get("ticker", ""), args.get("depth", 10)
        )

    def _tool_get_balance(self, args: dict) -> Dict[str, Any]:
        return get_balance(self._api_call)

    def _tool_get_positions(self, args: dict) -> Dict[str, Any]:
        return get_positions(self._api_call, ticker=args.get("ticker"))

    def _tool_place_order(self, args: dict) -> Dict[str, Any]:
        # Convert integer count to count_fp string (e.g. 10 → "10.00")
        count_val = args.get("count")
        count_fp = f"{int(count_val):.2f}" if count_val is not None else None
        return place_order(
            self._api_call,
            ticker=args.get("ticker", ""),
            side=args.get("side", "yes"),
            action=args.get("action", "buy"),
            count_fp=count_fp,
            yes_price_dollars=args.get("yes_price_dollars"),
            time_in_force=args.get("time_in_force"),
        )

    def _tool_cancel_order(self, args: dict) -> Dict[str, Any]:
        return cancel_order(self._api_call, args.get("order_id", ""))

    def _tool_get_orders(self, args: dict) -> Dict[str, Any]:
        return get_orders(
            self._api_call,
            ticker=args.get("ticker"),
            status=args.get("status"),
        )

    def _tool_get_trades(self, args: dict) -> Dict[str, Any]:
        return get_trades(
            self._api_call,
            ticker=args.get("ticker"),
            limit=args.get("limit", 20),
        )

    def _tool_get_events(self, args: dict) -> Dict[str, Any]:
        return get_events(
            self._api_call,
            series_ticker=args.get("series_ticker"),
            status=args.get("status", "open"),
            limit=args.get("limit", 20),
        )

    def _tool_get_event_detail(self, args: dict) -> Dict[str, Any]:
        return get_event_detail(self._api_call, args.get("event_ticker", ""))

    def _tool_get_fills(self, args: dict) -> Dict[str, Any]:
        return get_fills(
            self._api_call,
            ticker=args.get("ticker"),
            order_id=args.get("order_id"),
            limit=args.get("limit", 50),
        )

    def _tool_get_settlements(self, args: dict) -> Dict[str, Any]:
        return get_settlements(self._api_call, limit=args.get("limit", 50))

    def _tool_get_candlesticks(self, args: dict) -> Dict[str, Any]:
        return get_candlesticks(
            self._api_call,
            series_ticker=args.get("series_ticker", ""),
            ticker=args.get("ticker", ""),
            period_interval=args.get("period_interval", 60),
        )

    # --- Phase 2A: Order management handlers ---

    def _tool_amend_order(self, args: dict) -> Dict[str, Any]:
        count_val = args.get("count")
        count_fp = f"{int(count_val):.2f}" if count_val is not None else None
        return amend_order(
            self._api_call,
            order_id=args.get("order_id", ""),
            ticker=args.get("ticker", ""),
            side=args.get("side", "yes"),
            action=args.get("action", "buy"),
            count_fp=count_fp,
            yes_price_dollars=args.get("yes_price_dollars"),
        )

    def _tool_decrease_order(self, args: dict) -> Dict[str, Any]:
        reduce_by = args.get("reduce_by")
        reduce_to = args.get("reduce_to")
        return decrease_order(
            self._api_call,
            order_id=args.get("order_id", ""),
            reduce_by_fp=f"{int(reduce_by):.2f}" if reduce_by is not None else None,
            reduce_to_fp=f"{int(reduce_to):.2f}" if reduce_to is not None else None,
        )

    def _tool_batch_create_orders(self, args: dict) -> Dict[str, Any]:
        orders = args.get("orders", [])
        # Convert count → count_fp for each order
        for o in orders:
            if "count" in o and "count_fp" not in o:
                o["count_fp"] = f"{int(o.pop('count')):.2f}"
        return batch_create_orders(self._api_call, orders)

    def _tool_batch_cancel_orders(self, args: dict) -> Dict[str, Any]:
        return batch_cancel_orders(self._api_call, args.get("order_ids", []))

    # --- Phase 2A: Historical data handlers ---

    def _tool_get_historical_cutoff(self, args: dict) -> Dict[str, Any]:
        return get_historical_cutoff(self._api_call)

    def _tool_get_historical_markets(self, args: dict) -> Dict[str, Any]:
        return get_historical_markets(self._api_call, limit=args.get("limit", 50))

    def _tool_get_historical_market_detail(self, args: dict) -> Dict[str, Any]:
        return get_historical_market_detail(self._api_call, args.get("ticker", ""))

    def _tool_get_historical_fills(self, args: dict) -> Dict[str, Any]:
        return get_historical_fills(
            self._api_call, ticker=args.get("ticker"), limit=args.get("limit", 50)
        )

    def _tool_get_historical_orders(self, args: dict) -> Dict[str, Any]:
        return get_historical_orders(
            self._api_call,
            ticker=args.get("ticker"),
            status=args.get("status"),
            limit=args.get("limit", 50),
        )

    # --- Phase 2B: Exchange Info handlers ---

    def _tool_get_exchange_status(self, args: dict) -> Dict[str, Any]:
        return get_exchange_status(self._api_call)

    def _tool_get_exchange_schedule(self, args: dict) -> Dict[str, Any]:
        return get_exchange_schedule(self._api_call)

    def _tool_get_exchange_announcements(self, args: dict) -> Dict[str, Any]:
        return get_exchange_announcements(self._api_call)

    def _tool_get_fee_changes(self, args: dict) -> Dict[str, Any]:
        return get_fee_changes(
            self._api_call,
            series_ticker=args.get("series_ticker"),
            show_historical=args.get("show_historical", False),
        )

    def _tool_get_user_data_timestamp(self, args: dict) -> Dict[str, Any]:
        return get_user_data_timestamp(self._api_call)

    def _tool_get_account_limits(self, args: dict) -> Dict[str, Any]:
        return get_account_limits(self._api_call)

    # --- Phase 2B: Queue Position handlers ---

    def _tool_get_queue_position(self, args: dict) -> Dict[str, Any]:
        return get_queue_position(self._api_call, args.get("order_id", ""))

    def _tool_get_queue_positions(self, args: dict) -> Dict[str, Any]:
        return get_queue_positions(
            self._api_call,
            market_tickers=args.get("market_tickers"),
            event_ticker=args.get("event_ticker"),
        )

    # --- Phase 2B: Events Enhancement handlers ---

    def _tool_get_event_metadata(self, args: dict) -> Dict[str, Any]:
        return get_event_metadata(self._api_call, args.get("event_ticker", ""))

    def _tool_get_event_candlesticks(self, args: dict) -> Dict[str, Any]:
        return get_event_candlesticks(
            self._api_call,
            series_ticker=args.get("series_ticker", ""),
            event_ticker=args.get("event_ticker", ""),
            start_ts=args.get("start_ts", 0),
            end_ts=args.get("end_ts", 0),
            period_interval=args.get("period_interval", 60),
        )

    def _tool_get_forecast_percentiles(self, args: dict) -> Dict[str, Any]:
        return get_forecast_percentiles(
            self._api_call,
            series_ticker=args.get("series_ticker", ""),
            event_ticker=args.get("event_ticker", ""),
            percentiles=args.get("percentiles", [5000]),
            start_ts=args.get("start_ts", 0),
            end_ts=args.get("end_ts", 0),
            period_interval=args.get("period_interval", 60),
        )

    # --- Phase 2B: Advanced Market Data handlers ---

    def _tool_get_multivariate_events(self, args: dict) -> Dict[str, Any]:
        return get_multivariate_events(
            self._api_call,
            series_ticker=args.get("series_ticker"),
            collection_ticker=args.get("collection_ticker"),
            with_nested_markets=args.get("with_nested_markets", False),
            limit=args.get("limit", 20),
        )

    def _tool_get_historical_candlesticks(self, args: dict) -> Dict[str, Any]:
        return get_historical_candlesticks(
            self._api_call,
            ticker=args.get("ticker", ""),
            start_ts=args.get("start_ts", 0),
            end_ts=args.get("end_ts", 0),
            period_interval=args.get("period_interval", 60),
        )

    def _tool_get_sports_filters(self, args: dict) -> Dict[str, Any]:
        return get_sports_filters(self._api_call)

    # --- Phase 2B: Portfolio Enhancement handlers ---

    def _tool_get_resting_order_value(self, args: dict) -> Dict[str, Any]:
        return get_resting_order_value(self._api_call)

    # -----------------------------------------------------------------------
    # Core HTTP API method
    # -----------------------------------------------------------------------

    def _api_call(
        self,
        method: str,
        path: str,
        body: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> Dict[str, Any]:
        """
        Generic API call with RSA-PSS signing and rate limiting.

        Signs every request with:
        - KALSHI-ACCESS-KEY: API key ID
        - KALSHI-ACCESS-TIMESTAMP: milliseconds
        - KALSHI-ACCESS-SIGNATURE: RSA-PSS SHA256 signature
        """
        if not self._private_key:
            return {"error": "Not connected. Call connect() first."}

        if not self._rate_limiter.acquire(timeout=15.0):
            return {"error": "Rate limit timeout. Try again later."}

        url = f"{self._base_url}{path}"
        full_path = f"/trade-api/v2{path}"
        headers = self._sign_request(method.upper(), full_path)
        headers["Content-Type"] = "application/json"

        try:
            if method.upper() == "GET":
                resp = httpx.get(url, headers=headers, params=params, timeout=10.0)
            elif method.upper() == "POST":
                resp = httpx.post(url, headers=headers, json=body, timeout=10.0)
            elif method.upper() == "PUT":
                resp = httpx.put(url, headers=headers, json=body, timeout=10.0)
            elif method.upper() == "DELETE":
                # Use httpx.request to support DELETE with body (batch cancel)
                resp = httpx.request("DELETE", url, headers=headers, params=params, json=body, timeout=10.0)
            else:
                return {"error": f"Unsupported HTTP method: {method}"}
        except httpx.ConnectError:
            self._connected = False
            return {"error": "Cannot connect to Kalshi API. Check your network."}
        except httpx.TimeoutException:
            return {"error": "Request timed out."}

        # Handle HTTP errors
        if resp.status_code == 401:
            self._connected = False
            return {"error": "Authentication failed. Check your API key and private key."}
        if resp.status_code == 429:
            return {"error": "Rate limit exceeded. Slow down requests."}
        if resp.status_code == 404:
            return {"error": f"Not found: {path}"}
        if resp.status_code >= 400:
            try:
                err = resp.json()
                return {"error": f"API error ({resp.status_code}): {err.get('message', err)}"}
            except Exception:
                return {"error": f"API error ({resp.status_code}): {resp.text[:200]}"}

        # 204 No Content (e.g. DELETE API key)
        if resp.status_code == 204:
            return {"success": True}

        try:
            return resp.json()
        except Exception:
            return {"error": "Failed to parse JSON response."}

    def _sign_request(self, method: str, path: str) -> Dict[str, str]:
        """
        Generate RSA-PSS SHA-256 authentication headers.

        CRITICAL: Sign path WITHOUT query parameters.
        Salt length: PSS.DIGEST_LENGTH (per Kalshi docs).
        """
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding

        timestamp = str(int(time.time() * 1000))
        # Strip query params before signing
        path_clean = path.split("?")[0]
        message = f"{timestamp}{method}{path_clean}".encode("utf-8")

        signature = self._private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH,
            ),
            hashes.SHA256(),
        )

        return {
            "KALSHI-ACCESS-KEY": self._api_key_id,
            "KALSHI-ACCESS-TIMESTAMP": timestamp,
            "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode("utf-8"),
        }

    # -----------------------------------------------------------------------
    # Config loader
    # -----------------------------------------------------------------------

    def _load_engine_config(self) -> dict:
        config_path = _PLUGIN_DIR / "engine_config.json"
        if config_path.exists():
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load engine_config.json: {e}")
        return {}
