"""
Kalshi API — WebSocket module.

Handles real-time price streaming via ticker/trade/fill channels.
Used in WebSocket (Watchlist-only) engine mode.
"""

from typing import Any, Callable, Dict, List, Optional, Set
import asyncio
import json
import logging
import threading
import time
import base64

logger = logging.getLogger("kalshi_api.websocket")


class KalshiWebSocket:
    """
    Kalshi WebSocket client for real-time market data.

    Channels:
    - ticker: Price/volume updates (public, auth required for connection)
    - trade: Public trade executions
    - fill: User's fill notifications (private)
    - orderbook_delta: Orderbook snapshot + deltas (private)
    """

    def __init__(
        self,
        ws_url: str,
        api_key_id: str,
        private_key,
        on_ticker: Optional[Callable] = None,
        on_trade: Optional[Callable] = None,
        on_fill: Optional[Callable] = None,
    ):
        self._ws_url = ws_url
        self._api_key_id = api_key_id
        self._private_key = private_key
        self._on_ticker = on_ticker
        self._on_trade = on_trade
        self._on_fill = on_fill

        self._ws = None
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._running = False
        self._cmd_id = 0
        self._subscriptions: Dict[int, Dict[str, Any]] = {}  # sid -> info
        self._subscribed_tickers: Set[str] = set()

    @property
    def is_connected(self) -> bool:
        return self._running and self._ws is not None

    def start(self) -> bool:
        """Start WebSocket connection in background thread."""
        if self._running:
            logger.warning("WebSocket already running")
            return True

        self._running = True
        self._thread = threading.Thread(
            target=self._run_loop, daemon=True, name="kalshi-ws"
        )
        self._thread.start()
        logger.info("WebSocket thread started")
        return True

    def stop(self):
        """Stop WebSocket connection."""
        self._running = False
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5.0)
        self._ws = None
        self._subscriptions.clear()
        self._subscribed_tickers.clear()
        logger.info("WebSocket stopped")

    def subscribe_tickers(self, tickers: List[str]):
        """Subscribe to ticker channel for given market tickers."""
        if not tickers:
            return
        new_tickers = [t for t in tickers if t not in self._subscribed_tickers]
        if not new_tickers:
            return
        if self._loop and self._ws:
            asyncio.run_coroutine_threadsafe(
                self._send_subscribe("ticker", new_tickers), self._loop
            )

    def unsubscribe_tickers(self, tickers: List[str]):
        """Unsubscribe from specific tickers."""
        # Find SIDs for ticker channel, then update_subscription with delete_markets
        if not tickers or not self._loop or not self._ws:
            return
        ticker_sids = [
            sid for sid, info in self._subscriptions.items()
            if info.get("channel") == "ticker"
        ]
        if ticker_sids:
            asyncio.run_coroutine_threadsafe(
                self._send_update_subscription(
                    ticker_sids[0], tickers, "delete_markets"
                ),
                self._loop,
            )
        for t in tickers:
            self._subscribed_tickers.discard(t)

    # -----------------------------------------------------------------------
    # Internal: event loop & connection
    # -----------------------------------------------------------------------

    def _run_loop(self):
        """Run asyncio event loop in background thread."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._connect_and_listen())
        except Exception as e:
            logger.error(f"WebSocket loop error: {e}")
        finally:
            self._loop.close()
            self._loop = None

    async def _connect_and_listen(self):
        """Connect with authentication and listen for messages."""
        try:
            import websockets
        except ImportError:
            logger.error("websockets package not installed")
            return

        while self._running:
            try:
                headers = self._build_auth_headers()
                async with websockets.connect(
                    self._ws_url,
                    additional_headers=headers,
                    ping_interval=None,  # Kalshi sends pings
                ) as ws:
                    self._ws = ws
                    logger.info(f"WebSocket connected to {self._ws_url}")

                    # Re-subscribe if reconnecting
                    if self._subscribed_tickers:
                        await self._send_subscribe(
                            "ticker", list(self._subscribed_tickers)
                        )

                    async for message in ws:
                        if not self._running:
                            break
                        self._handle_message(message)

            except Exception as e:
                logger.warning(f"WebSocket connection error: {e}")
                self._ws = None
                if self._running:
                    await asyncio.sleep(5.0)  # Reconnect delay

    def _build_auth_headers(self) -> Dict[str, str]:
        """Build RSA-PSS authentication headers for WS handshake."""
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding

        timestamp = str(int(time.time() * 1000))
        message = f"{timestamp}GET/trade-api/ws/v2".encode("utf-8")

        signature = self._private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH,
            ),
            hashes.SHA256(),
        )

        return {
            "KALSHI-ACCESS-KEY": self._api_key_id,
            "KALSHI-ACCESS-TIMESTAMP": timestamp,
            "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode("utf-8"),
        }

    # -----------------------------------------------------------------------
    # Internal: message handling
    # -----------------------------------------------------------------------

    def _handle_message(self, raw: str):
        """Parse and dispatch incoming WebSocket message."""
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning(f"Invalid JSON: {raw[:200]}")
            return

        msg_type = data.get("type", "")

        if msg_type == "subscribed":
            sid = data.get("msg", {}).get("sid")
            channel = data.get("msg", {}).get("channel", "")
            if sid:
                self._subscriptions[sid] = {"channel": channel}
            logger.debug(f"Subscribed to {channel} (sid={sid})")

        elif msg_type == "ticker":
            self._handle_ticker(data)

        elif msg_type == "trade":
            self._handle_trade(data)

        elif msg_type == "fill":
            self._handle_fill(data)

        elif msg_type == "error":
            err = data.get("msg", {})
            logger.warning(f"WS error: code={err.get('code')} msg={err.get('msg')}")

        elif msg_type in ("orderbook_snapshot", "orderbook_delta"):
            pass  # Can be extended if needed

    def _handle_ticker(self, data: Dict[str, Any]):
        """Process ticker update."""
        msg = data.get("msg", {})
        parsed = {
            "ticker": msg.get("market_ticker", ""),
            "yes_bid": msg.get("yes_bid_dollars", ""),
            "yes_ask": msg.get("yes_ask_dollars", ""),
            "yes_bid_size_fp": msg.get("yes_bid_size_fp", "0.00"),
            "yes_ask_size_fp": msg.get("yes_ask_size_fp", "0.00"),
            "last_price": msg.get("price_dollars", ""),
            "volume": msg.get("volume", 0),
            "open_interest": msg.get("open_interest", 0),
            "ts": msg.get("ts", 0),
        }
        if self._on_ticker:
            try:
                self._on_ticker(parsed)
            except Exception as e:
                logger.error(f"Ticker callback error: {e}")

    def _handle_trade(self, data: Dict[str, Any]):
        """Process trade event."""
        msg = data.get("msg", {})
        parsed = {
            "trade_id": msg.get("trade_id", ""),
            "ticker": msg.get("market_ticker", ""),
            "yes_price": msg.get("yes_price_dollars", ""),
            "count": msg.get("count_fp", str(msg.get("count", 0))),
            "taker_side": msg.get("taker_side", ""),
            "ts": msg.get("ts", 0),
        }
        if self._on_trade:
            try:
                self._on_trade(parsed)
            except Exception as e:
                logger.error(f"Trade callback error: {e}")

    def _handle_fill(self, data: Dict[str, Any]):
        """Process fill notification (private)."""
        msg = data.get("msg", {})
        parsed = {
            "trade_id": msg.get("trade_id", ""),
            "order_id": msg.get("order_id", ""),
            "ticker": msg.get("market_ticker", ""),
            "side": msg.get("side", ""),
            "action": msg.get("action", ""),
            "yes_price": msg.get("yes_price_dollars", ""),
            "count": msg.get("count_fp", str(msg.get("count", 0))),
            "is_taker": msg.get("is_taker", False),
            "fee_cost": msg.get("fee_cost", "0"),
        }
        if self._on_fill:
            try:
                self._on_fill(parsed)
            except Exception as e:
                logger.error(f"Fill callback error: {e}")

    # -----------------------------------------------------------------------
    # Internal: send commands
    # -----------------------------------------------------------------------

    async def _send_subscribe(self, channel: str, tickers: List[str]):
        """Send subscribe command."""
        if not self._ws:
            return
        self._cmd_id += 1
        cmd = {
            "id": self._cmd_id,
            "cmd": "subscribe",
            "params": {
                "channels": [channel],
                "market_tickers": tickers,
                "send_initial_snapshot": True,
            },
        }
        await self._ws.send(json.dumps(cmd))
        for t in tickers:
            self._subscribed_tickers.add(t)
        logger.debug(f"Subscribe sent: {channel} for {len(tickers)} tickers")

    async def _send_update_subscription(
        self, sid: int, tickers: List[str], action: str
    ):
        """Send update_subscription command (add/delete markets)."""
        if not self._ws:
            return
        self._cmd_id += 1
        cmd = {
            "id": self._cmd_id,
            "cmd": "update_subscription",
            "params": {
                "sids": [sid],
                "market_tickers": tickers,
                "action": action,
            },
        }
        await self._ws.send(json.dumps(cmd))
        logger.debug(f"Update subscription: {action} {len(tickers)} tickers")

    async def _send_unsubscribe(self, sids: List[int]):
        """Send unsubscribe command."""
        if not self._ws:
            return
        self._cmd_id += 1
        cmd = {
            "id": self._cmd_id,
            "cmd": "unsubscribe",
            "params": {"sids": sids},
        }
        await self._ws.send(json.dumps(cmd))
        for sid in sids:
            self._subscriptions.pop(sid, None)
        logger.debug(f"Unsubscribed from sids: {sids}")
