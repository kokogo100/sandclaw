"""
Kalshi API — Markets & Events module.

Handles market data retrieval, events, orderbook, candlesticks, and trades.
Uses batch requests and category filters for efficient polling.
"""

from typing import Any, Callable, Dict, List, Optional
import logging
import time

logger = logging.getLogger("kalshi_api.markets")

# ---------------------------------------------------------------------------
# Market ID → Kalshi API category name mapping
# Used by get_tickers_for_market() via GET /series?category=
# ---------------------------------------------------------------------------
CATEGORY_API_MAP: Dict[str, str] = {
    "kalshi_crypto": "Crypto",
    "kalshi_economics": "Economics",
    "kalshi_politics": "Politics",
    "kalshi_elections": "Elections",
    "kalshi_climate": "Climate and Weather",
    "kalshi_sports": "Sports",
    "kalshi_entertainment": "Entertainment",
    "kalshi_tech": "Science and Technology",
    "kalshi_financials": "Financials",
    "kalshi_companies": "Companies",
    "kalshi_mentions": "Mentions",
    "kalshi_social": "Social",
    "kalshi_world": "World",
}

# Legacy alias for backward compatibility (main.py imports this)
CATEGORY_SERIES_MAP = CATEGORY_API_MAP

# Kalshi market status values
MARKET_STATUS_OPEN = "open"
MARKET_STATUS_CLOSED = "closed"
MARKET_STATUS_SETTLED = "settled"


def get_markets(
    api_call: Callable,
    limit: int = 200,
    cursor: Optional[str] = None,
    status: str = MARKET_STATUS_OPEN,
    series_ticker: Optional[str] = None,
    event_ticker: Optional[str] = None,
    tickers: Optional[str] = None,
    min_close_ts: Optional[int] = None,
    max_close_ts: Optional[int] = None,
) -> Dict[str, Any]:
    """
    GET /markets — List markets with filters.

    Args:
        tickers: Comma-separated market tickers for batch lookup.
    Returns: {"markets": [...], "cursor": str|None}
    """
    params: Dict[str, Any] = {"limit": limit, "status": status}
    if cursor:
        params["cursor"] = cursor
    if series_ticker:
        params["series_ticker"] = series_ticker
    if event_ticker:
        params["event_ticker"] = event_ticker
    if tickers:
        params["tickers"] = tickers
    if min_close_ts:
        params["min_close_ts"] = min_close_ts
    if max_close_ts:
        params["max_close_ts"] = max_close_ts

    result = api_call("GET", "/markets", params=params)
    if "error" in result:
        return result

    markets = result.get("markets", [])
    return {
        "markets": [_parse_market(m) for m in markets],
        "cursor": result.get("cursor"),
        "count": len(markets),
    }


def get_market_detail(api_call: Callable, ticker: str) -> Dict[str, Any]:
    """
    GET /markets/{ticker} — Single market details.
    """
    if not ticker:
        return {"error": "Market ticker is required"}

    result = api_call("GET", f"/markets/{ticker}")
    if "error" in result:
        return result

    market = result.get("market", result)
    return _parse_market(market)


def get_orderbook(
    api_call: Callable, ticker: str, depth: int = 0
) -> Dict[str, Any]:
    """
    GET /markets/{ticker}/orderbook — Orderbook (YES/NO bids).

    depth: 0 = all levels, 1-100 = limit depth
    """
    if not ticker:
        return {"error": "Market ticker is required"}

    params = {}
    if depth > 0:
        params["depth"] = depth

    result = api_call("GET", f"/markets/{ticker}/orderbook", params=params)
    if "error" in result:
        return result

    ob = result.get("orderbook", {})
    ob_fp = result.get("orderbook_fp", {})

    return {
        "ticker": ticker,
        "yes_bids": ob.get("yes", []),
        "no_bids": ob.get("no", []),
        "yes_bids_dollars": ob_fp.get("yes_dollars", []),
        "no_bids_dollars": ob_fp.get("no_dollars", []),
    }


def get_events(
    api_call: Callable,
    limit: int = 100,
    cursor: Optional[str] = None,
    status: str = "open",
    series_ticker: Optional[str] = None,
    with_nested_markets: bool = False,
) -> Dict[str, Any]:
    """
    GET /events — List events.
    """
    params: Dict[str, Any] = {"limit": limit, "status": status}
    if cursor:
        params["cursor"] = cursor
    if series_ticker:
        params["series_ticker"] = series_ticker
    if with_nested_markets:
        params["with_nested_markets"] = "true"

    result = api_call("GET", "/events", params=params)
    if "error" in result:
        return result

    events = result.get("events", [])
    return {
        "events": [_parse_event(e) for e in events],
        "cursor": result.get("cursor"),
        "count": len(events),
    }


def get_event_detail(
    api_call: Callable, event_ticker: str, with_markets: bool = True
) -> Dict[str, Any]:
    """
    GET /events/{event_ticker} — Single event with optional nested markets.
    """
    if not event_ticker:
        return {"error": "Event ticker is required"}

    params = {}
    if with_markets:
        params["with_nested_markets"] = "true"

    result = api_call("GET", f"/events/{event_ticker}", params=params)
    if "error" in result:
        return result

    event = result.get("event", result)
    markets = result.get("markets", [])
    parsed = _parse_event(event)
    if markets:
        parsed["markets"] = [_parse_market(m) for m in markets]
    return parsed


def get_trades(
    api_call: Callable,
    ticker: Optional[str] = None,
    limit: int = 100,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """
    GET /markets/trades — Recent trades.
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    if ticker:
        params["ticker"] = ticker

    result = api_call("GET", "/markets/trades", params=params)
    if "error" in result:
        return result

    trades = result.get("trades", [])
    return {
        "trades": [_parse_trade(t) for t in trades],
        "cursor": result.get("cursor"),
        "count": len(trades),
    }


def get_candlesticks(
    api_call: Callable,
    series_ticker: str,
    ticker: str,
    period_interval: int = 60,
) -> Dict[str, Any]:
    """
    GET /series/{series}/markets/{ticker}/candlesticks — OHLC data.

    period_interval: 1 (1min), 60 (1hr), 1440 (1day)
    """
    if not series_ticker or not ticker:
        return {"error": "Both series_ticker and ticker are required"}

    params = {"period_interval": period_interval}
    result = api_call(
        "GET",
        f"/series/{series_ticker}/markets/{ticker}/candlesticks",
        params=params,
    )
    if "error" in result:
        return result

    return {
        "ticker": ticker,
        "candlesticks": result.get("candlesticks", []),
    }


# ---------------------------------------------------------------------------
# Batch price lookup — GET /markets?tickers=A,B,C
# ---------------------------------------------------------------------------

def get_batch_prices(
    api_call: Callable, tickers_list: List[str], chunk_size: int = 100
) -> Dict[str, Dict[str, Any]]:
    """
    Batch price fetch via GET /markets?tickers=A,B,C.
    Returns {ticker: {last_price, yes_bid, yes_ask, volume, ...}}.

    Kalshi API accepts comma-separated tickers in one call (limit=1000).
    We chunk at `chunk_size` for safety.
    """
    result_map: Dict[str, Dict[str, Any]] = {}

    for i in range(0, len(tickers_list), chunk_size):
        chunk = tickers_list[i : i + chunk_size]
        tickers_csv = ",".join(chunk)

        resp = get_markets(api_call, limit=len(chunk), tickers=tickers_csv)
        if "error" in resp:
            logger.warning(f"Batch price fetch failed: {resp}")
            continue

        for raw_market in resp.get("markets", []):
            parsed = _parse_market(raw_market)
            result_map[parsed["ticker"]] = parsed

    return result_map


# ---------------------------------------------------------------------------
# Batch / Category helpers — for engine polling
# ---------------------------------------------------------------------------

def get_tickers_for_market(
    api_call: Callable, market: str
) -> List[Dict[str, Any]]:
    """
    Get all tickers for a given market category.
    Used by engine's get_all_tickers() in REST API polling mode.

    Supports:
    - kalshi_all: All open markets (paginated)
    - kalshi_top_volume: Top 100 by trading volume
    - kalshi_closing_soon: Markets closing within 24h
    - kalshi_<category>: Category-based via GET /series?category=
    """
    if market == "kalshi_all":
        return _fetch_all_open_markets(api_call)

    if market == "kalshi_top_volume":
        return _fetch_top_volume(api_call, top_n=100)

    if market == "kalshi_closing_soon":
        return _fetch_closing_soon(api_call, hours=24)

    # Category-based filtering via GET /series?category= API
    api_category = CATEGORY_API_MAP.get(market)
    if not api_category:
        logger.warning(f"Unknown market category: {market}")
        return []

    return _fetch_by_category(api_call, api_category)


def _fetch_by_category(
    api_call: Callable, category: str
) -> List[Dict[str, Any]]:
    """Fetch markets for a category via GET /series?category= then expand."""
    # Step 1: Get all series in this category
    result = api_call("GET", "/series", params={"category": category})
    if "error" in result:
        logger.warning(f"Failed to fetch series for category={category}: {result}")
        return []

    series_list = result.get("series", [])
    if not series_list:
        return []

    # Step 2: For each series, fetch open markets
    all_markets: List[Dict[str, Any]] = []
    seen_tickers = set()

    for series in series_list:
        s_ticker = series.get("ticker") or series.get("series_ticker", "")
        if not s_ticker:
            continue

        mkts = get_markets(api_call, limit=200, series_ticker=s_ticker, status="open")
        if "error" not in mkts:
            for m in mkts.get("markets", []):
                ticker = m.get("ticker", "")
                if ticker and ticker not in seen_tickers:
                    seen_tickers.add(ticker)
                    all_markets.append(m)

    return all_markets


def _fetch_all_open_markets(api_call: Callable) -> List[Dict[str, Any]]:
    """Paginate through all open markets."""
    all_markets: List[Dict[str, Any]] = []
    cursor = None
    max_pages = 10  # Safety limit

    for _ in range(max_pages):
        result = get_markets(api_call, limit=1000, cursor=cursor, status="open")
        if "error" in result:
            break
        all_markets.extend(result.get("markets", []))
        cursor = result.get("cursor")
        if not cursor:
            break

    return all_markets


def _fetch_top_volume(
    api_call: Callable, top_n: int = 100
) -> List[Dict[str, Any]]:
    """Fetch all open markets, sort by volume, return top N."""
    all_markets = _fetch_all_open_markets(api_call)
    all_markets.sort(key=lambda m: m.get("volume", 0), reverse=True)
    return all_markets[:top_n]


def _fetch_closing_soon(
    api_call: Callable, hours: int = 24
) -> List[Dict[str, Any]]:
    """Fetch markets closing within N hours."""
    now_ts = int(time.time())
    max_close_ts = now_ts + (hours * 3600)

    result = get_markets(
        api_call, limit=1000, status="open", max_close_ts=max_close_ts
    )
    if "error" in result:
        return []

    markets = result.get("markets", [])
    # Sort by close time ascending (soonest first)
    markets.sort(key=lambda m: m.get("close_time", ""))
    return markets


# ---------------------------------------------------------------------------
# Parsers — normalize raw API responses
# ---------------------------------------------------------------------------

def _parse_market(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize a market object from API response."""
    return {
        "ticker": raw.get("ticker", ""),
        "event_ticker": raw.get("event_ticker", ""),
        "title": raw.get("title", raw.get("yes_sub_title", "")),
        "status": raw.get("status", ""),
        "market_type": raw.get("market_type", "binary"),
        # Prices (fixed-point dollars preferred)
        "yes_bid": raw.get("yes_bid_dollars", ""),
        "yes_ask": raw.get("yes_ask_dollars", ""),
        "no_bid": raw.get("no_bid_dollars", ""),
        "no_ask": raw.get("no_ask_dollars", ""),
        "last_price": raw.get("last_price_dollars", ""),
        # L1 size (fixed-point)
        "yes_bid_size_fp": raw.get("yes_bid_size_fp", ""),
        "yes_ask_size_fp": raw.get("yes_ask_size_fp", ""),
        # Volume & interest
        "volume": raw.get("volume", 0),
        "volume_24h": raw.get("volume_24h", 0),
        "open_interest": raw.get("open_interest", 0),
        # Metadata
        "yes_sub_title": raw.get("yes_sub_title", ""),
        "no_sub_title": raw.get("no_sub_title", ""),
        "open_time": raw.get("open_time", ""),
        "close_time": raw.get("close_time", ""),
        "result": raw.get("result", ""),
        "rules_primary": raw.get("rules_primary", ""),
        "notional_value": raw.get("notional_value_dollars", ""),
        "can_close_early": raw.get("can_close_early", False),
    }


def _parse_event(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize an event object."""
    return {
        "event_ticker": raw.get("event_ticker", ""),
        "series_ticker": raw.get("series_ticker", ""),
        "title": raw.get("title", ""),
        "sub_title": raw.get("sub_title", ""),
        "category": raw.get("category", ""),
        "mutually_exclusive": raw.get("mutually_exclusive", False),
        "strike_date": raw.get("strike_date"),
        "strike_period": raw.get("strike_period", ""),
    }


def _parse_trade(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize a trade object."""
    return {
        "trade_id": raw.get("trade_id", ""),
        "ticker": raw.get("ticker", ""),
        "yes_price": raw.get("yes_price_dollars", ""),
        "no_price": raw.get("no_price_dollars", ""),
        "count": raw.get("count_fp", raw.get("count", 0)),
        "taker_side": raw.get("taker_side", ""),
        "created_time": raw.get("created_time", ""),
    }


# ---------------------------------------------------------------------------
# Phase 2B: Event metadata, event candlesticks, forecast percentiles,
#            multivariate events, historical candlesticks, sports filters
# ---------------------------------------------------------------------------

def get_event_metadata(
    api_call: Callable, event_ticker: str
) -> Dict[str, Any]:
    """
    GET /events/{event_ticker}/metadata — Event metadata.

    Returns image URLs, market color codes, and settlement sources.
    """
    if not event_ticker:
        return {"error": "Event ticker is required"}

    result = api_call("GET", f"/events/{event_ticker}/metadata")
    if "error" in result:
        return result

    return {
        "event_ticker": event_ticker,
        "image_url": result.get("image_url", ""),
        "featured_image_url": result.get("featured_image_url", ""),
        "market_details": result.get("market_details", []),
        "settlement_sources": result.get("settlement_sources", []),
        "competition": result.get("competition", ""),
        "competition_scope": result.get("competition_scope", ""),
    }


def get_event_candlesticks(
    api_call: Callable,
    series_ticker: str,
    event_ticker: str,
    start_ts: int,
    end_ts: int,
    period_interval: int = 60,
) -> Dict[str, Any]:
    """
    GET /series/{series_ticker}/events/{ticker}/candlesticks — Event-level OHLC.

    Aggregated candlestick data across all markets for the event.

    Args:
        series_ticker: Series containing the event
        event_ticker: Event ticker
        start_ts: Start unix timestamp
        end_ts: End unix timestamp
        period_interval: 1 (1min), 60 (1hr), 1440 (1day)
    """
    if not series_ticker or not event_ticker:
        return {"error": "Both series_ticker and event_ticker are required"}

    params = {
        "start_ts": start_ts,
        "end_ts": end_ts,
        "period_interval": period_interval,
    }
    result = api_call(
        "GET",
        f"/series/{series_ticker}/events/{event_ticker}/candlesticks",
        params=params,
    )
    if "error" in result:
        return result

    return {
        "event_ticker": event_ticker,
        "candlesticks": result.get("candlesticks", []),
    }


def get_forecast_percentiles(
    api_call: Callable,
    series_ticker: str,
    event_ticker: str,
    percentiles: List[int],
    start_ts: int,
    end_ts: int,
    period_interval: int = 60,
) -> Dict[str, Any]:
    """
    GET /series/{series_ticker}/events/{ticker}/forecast_percentile_history

    Forecast percentile history for an event.

    Args:
        percentiles: List of percentile values (0-10000, max 10 items)
        start_ts: Start unix timestamp
        end_ts: End unix timestamp
        period_interval: 0, 1, 60, or 1440 minutes
    """
    if not series_ticker or not event_ticker:
        return {"error": "Both series_ticker and event_ticker are required"}
    if not percentiles:
        return {"error": "At least one percentile value is required"}

    params: Dict[str, Any] = {
        "start_ts": start_ts,
        "end_ts": end_ts,
        "period_interval": period_interval,
    }
    # Send percentiles as comma-separated
    params["percentiles"] = ",".join(str(p) for p in percentiles[:10])

    result = api_call(
        "GET",
        f"/series/{series_ticker}/events/{event_ticker}/forecast_percentile_history",
        params=params,
    )
    if "error" in result:
        return result

    return {
        "event_ticker": event_ticker,
        "histories": result.get("histories", []),
    }


def get_multivariate_events(
    api_call: Callable,
    limit: int = 100,
    cursor: Optional[str] = None,
    series_ticker: Optional[str] = None,
    collection_ticker: Optional[str] = None,
    with_nested_markets: bool = False,
) -> Dict[str, Any]:
    """
    GET /events/multivariate — List multivariate events.

    Multivariate events have multiple interrelated outcome markets.

    Args:
        series_ticker: Filter by series (cannot combine with collection_ticker)
        collection_ticker: Filter by collection (cannot combine with series_ticker)
        with_nested_markets: Include nested market objects
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    if series_ticker:
        params["series_ticker"] = series_ticker
    if collection_ticker:
        params["collection_ticker"] = collection_ticker
    if with_nested_markets:
        params["with_nested_markets"] = "true"

    result = api_call("GET", "/events/multivariate", params=params)
    if "error" in result:
        return result

    events = result.get("events", [])
    return {
        "events": [_parse_event(e) for e in events],
        "cursor": result.get("cursor"),
        "count": len(events),
    }


def get_historical_candlesticks(
    api_call: Callable,
    ticker: str,
    start_ts: int,
    end_ts: int,
    period_interval: int = 60,
) -> Dict[str, Any]:
    """
    GET /historical/markets/{ticker}/candlesticks — Historical OHLC data.

    For settled markets older than the live/historical cutoff.

    Args:
        ticker: Market ticker
        start_ts: Start unix timestamp
        end_ts: End unix timestamp
        period_interval: 1 (1min), 60 (1hr), 1440 (1day)
    """
    if not ticker:
        return {"error": "Market ticker is required"}

    params = {
        "start_ts": start_ts,
        "end_ts": end_ts,
        "period_interval": period_interval,
    }
    result = api_call(
        "GET",
        f"/historical/markets/{ticker}/candlesticks",
        params=params,
    )
    if "error" in result:
        return result

    return {
        "ticker": ticker,
        "candlesticks": result.get("candlesticks", []),
    }


def get_sports_filters(api_call: Callable) -> Dict[str, Any]:
    """
    GET /search/filters_by_sport — Available sports filters.

    Returns sport categories with scopes, competitions, and display order.
    """
    result = api_call("GET", "/search/filters_by_sport")
    if "error" in result:
        return result

    return result
