"""
Kalshi API — Trading module.

Handles orders, portfolio, balance, fills, and settlements.
"""

from typing import Any, Callable, Dict, List, Optional
import logging

logger = logging.getLogger("kalshi_api.trading")


def _to_float(val: Any) -> float:
    """Safely convert dollar string or number to float."""
    try:
        return float(val) if val else 0.0
    except (ValueError, TypeError):
        return 0.0


# ---------------------------------------------------------------------------
# Portfolio endpoints
# ---------------------------------------------------------------------------

def get_balance(api_call: Callable, subaccount: Optional[int] = None) -> Dict[str, Any]:
    """
    GET /portfolio/balance — Account balance.

    Returns balance in USD dollars (fixed-point string fields).
    NOTE: Legacy integer cent fields (balance, portfolio_value) deprecated March 5, 2026.
    """
    params = {}
    if subaccount is not None:
        params["subaccount"] = subaccount

    result = api_call("GET", "/portfolio/balance", params=params)
    if "error" in result:
        return result

    balance_dollars = _to_float(result.get("balance_dollars", "0.00"))
    portfolio_dollars = _to_float(result.get("portfolio_value_dollars", "0.00"))

    return {
        "balance_dollars": balance_dollars,
        "portfolio_value_dollars": portfolio_dollars,
        "updated_ts": result.get("updated_ts"),
    }


def get_positions(
    api_call: Callable,
    ticker: Optional[str] = None,
    event_ticker: Optional[str] = None,
    limit: int = 100,
    cursor: Optional[str] = None,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    GET /portfolio/positions — Current positions.

    position > 0: YES position, position < 0: NO position
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    if ticker:
        params["ticker"] = ticker
    if event_ticker:
        params["event_ticker"] = event_ticker
    if subaccount is not None:
        params["subaccount"] = subaccount

    result = api_call("GET", "/portfolio/positions", params=params)
    if "error" in result:
        return result

    positions = result.get("market_positions", [])
    return {
        "positions": [_parse_position(p) for p in positions],
        "event_positions": result.get("event_positions", []),
        "cursor": result.get("cursor"),
        "count": len(positions),
    }


def get_fills(
    api_call: Callable,
    ticker: Optional[str] = None,
    order_id: Optional[str] = None,
    limit: int = 100,
    cursor: Optional[str] = None,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    GET /portfolio/fills — Fill history.
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    if ticker:
        params["ticker"] = ticker
    if order_id:
        params["order_id"] = order_id
    if subaccount is not None:
        params["subaccount"] = subaccount

    result = api_call("GET", "/portfolio/fills", params=params)
    if "error" in result:
        return result

    fills = result.get("fills", [])
    return {
        "fills": [_parse_fill(f) for f in fills],
        "cursor": result.get("cursor"),
        "count": len(fills),
    }


def get_settlements(
    api_call: Callable,
    limit: int = 100,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """
    GET /portfolio/settlements — Settlement history.
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor

    result = api_call("GET", "/portfolio/settlements", params=params)
    if "error" in result:
        return result

    return {
        "settlements": result.get("settlements", []),
        "cursor": result.get("cursor"),
    }


# ---------------------------------------------------------------------------
# Order endpoints
# ---------------------------------------------------------------------------

def place_order(
    api_call: Callable,
    ticker: str,
    side: str,
    action: str = "buy",
    count: Optional[int] = None,
    count_fp: Optional[str] = None,
    yes_price_dollars: Optional[str] = None,
    no_price_dollars: Optional[str] = None,
    client_order_id: Optional[str] = None,
    time_in_force: Optional[str] = None,
    expiration_ts: Optional[int] = None,
    post_only: bool = False,
    reduce_only: bool = False,
    buy_max_cost_dollars: Optional[str] = None,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    POST /portfolio/orders — Create order.

    Args:
        ticker: Market ticker (e.g. "KXBTCD-26MAR14-B59500")
        side: "yes" or "no"
        action: "buy" or "sell"
        count: Number of contracts (integer, deprecated)
        count_fp: Number of contracts (fixed-point string, e.g. "10.00")
        yes_price_dollars: Limit price for YES side (e.g. "0.4800")
        no_price_dollars: Limit price for NO side (e.g. "0.5200")
        client_order_id: Idempotency key
        time_in_force: "fill_or_kill" / "good_till_canceled" / "immediate_or_cancel"
        expiration_ts: Order expiration unix timestamp
        post_only: Maker only
        reduce_only: Only reduce existing position
        buy_max_cost_dollars: Max cost in dollars (e.g. "5.00", enables FOK)
        subaccount: 0=primary, 1-32
    """
    if not ticker:
        return {"error": "Market ticker is required"}
    if side not in ("yes", "no"):
        return {"error": "Side must be 'yes' or 'no'"}
    if action not in ("buy", "sell"):
        return {"error": "Action must be 'buy' or 'sell'"}
    # Auto-convert deprecated integer count → count_fp string
    if count_fp is None and count is not None:
        count_fp = f"{int(count):.2f}"
    if count_fp is None:
        return {"error": "Either count or count_fp is required"}

    body: Dict[str, Any] = {
        "ticker": ticker,
        "side": side,
        "action": action,
        "type": "limit",
        "count_fp": count_fp,
    }

    if yes_price_dollars:
        body["yes_price_dollars"] = yes_price_dollars
    if no_price_dollars:
        body["no_price_dollars"] = no_price_dollars
    if client_order_id:
        body["client_order_id"] = client_order_id
    if time_in_force:
        body["time_in_force"] = time_in_force
    if expiration_ts:
        body["expiration_ts"] = expiration_ts
    if post_only:
        body["post_only"] = True
    if reduce_only:
        body["reduce_only"] = True
    if buy_max_cost_dollars is not None:
        body["buy_max_cost_dollars"] = buy_max_cost_dollars
    if subaccount is not None:
        body["subaccount"] = subaccount

    result = api_call("POST", "/portfolio/orders", body=body)
    if "error" in result:
        return result

    order = result.get("order", result)
    return _parse_order(order)


def cancel_order(
    api_call: Callable,
    order_id: str,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    DELETE /portfolio/orders/{order_id} — Cancel order.
    """
    if not order_id:
        return {"error": "Order ID is required"}

    params = {}
    if subaccount is not None:
        params["subaccount"] = subaccount

    result = api_call("DELETE", f"/portfolio/orders/{order_id}", params=params)
    if "error" in result:
        return result

    order = result.get("order", result)
    return {
        "order": _parse_order(order),
        "reduced_by": result.get("reduced_by_fp", result.get("reduced_by", 0)),
    }


def amend_order(
    api_call: Callable,
    order_id: str,
    ticker: str,
    side: str,
    action: str,
    count_fp: Optional[str] = None,
    yes_price_dollars: Optional[str] = None,
    no_price_dollars: Optional[str] = None,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    POST /portfolio/orders/{order_id}/amend — Modify order price/quantity.

    Retains queue position if only reducing quantity.
    Exactly one price field (yes_price_dollars or no_price_dollars) should be provided.
    """
    if not order_id:
        return {"error": "Order ID is required"}

    body: Dict[str, Any] = {
        "ticker": ticker,
        "side": side,
        "action": action,
    }
    if count_fp is not None:
        body["count_fp"] = count_fp
    if yes_price_dollars is not None:
        body["yes_price_dollars"] = yes_price_dollars
    if no_price_dollars is not None:
        body["no_price_dollars"] = no_price_dollars
    if subaccount is not None:
        body["subaccount"] = subaccount

    result = api_call("POST", f"/portfolio/orders/{order_id}/amend", body=body)
    if "error" in result:
        return result

    order = result.get("order", result)
    return _parse_order(order)


def decrease_order(
    api_call: Callable,
    order_id: str,
    reduce_by_fp: Optional[str] = None,
    reduce_to_fp: Optional[str] = None,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    POST /portfolio/orders/{order_id}/decrease — Reduce order quantity (retains queue position).

    Provide either reduce_by_fp (reduce BY N contracts) or reduce_to_fp (reduce TO N contracts).
    """
    if not order_id:
        return {"error": "Order ID is required"}
    if reduce_by_fp is None and reduce_to_fp is None:
        return {"error": "Either reduce_by_fp or reduce_to_fp is required"}

    body: Dict[str, Any] = {}
    if reduce_by_fp is not None:
        body["reduce_by_fp"] = reduce_by_fp
    if reduce_to_fp is not None:
        body["reduce_to_fp"] = reduce_to_fp
    if subaccount is not None:
        body["subaccount"] = subaccount

    result = api_call("POST", f"/portfolio/orders/{order_id}/decrease", body=body)
    if "error" in result:
        return result

    order = result.get("order", result)
    return _parse_order(order)


def batch_create_orders(
    api_call: Callable,
    orders: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    POST /portfolio/orders/batched — Create up to 20 orders in one request.

    Each order dict should have: ticker, side, action, count_fp, yes_price_dollars, etc.
    """
    if not orders:
        return {"error": "Orders list is required"}
    if len(orders) > 20:
        return {"error": "Maximum 20 orders per batch"}

    result = api_call("POST", "/portfolio/orders/batched", body={"orders": orders})
    if "error" in result:
        return result

    raw_orders = result.get("orders", [])
    return {
        "orders": [_parse_order(o) for o in raw_orders],
        "count": len(raw_orders),
    }


def batch_cancel_orders(
    api_call: Callable,
    order_ids: List[str],
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    DELETE /portfolio/orders/batched — Cancel up to 20 orders in one request.

    Each cancellation costs 0.2 write transactions.
    """
    if not order_ids:
        return {"error": "Order IDs list is required"}
    if len(order_ids) > 20:
        return {"error": "Maximum 20 cancellations per batch"}

    cancel_items = [{"order_id": oid} for oid in order_ids]
    if subaccount is not None:
        for item in cancel_items:
            item["subaccount"] = subaccount

    result = api_call("DELETE", "/portfolio/orders/batched", body={"orders": cancel_items})
    if "error" in result:
        return result

    raw_orders = result.get("orders", [])
    return {
        "orders": [
            {
                "order": _parse_order(o.get("order", o)),
                "reduced_by": o.get("reduced_by_fp", "0"),
            }
            for o in raw_orders
        ],
        "count": len(raw_orders),
    }


# ---------------------------------------------------------------------------
# Historical data endpoints (data older than live cutoff)
# ---------------------------------------------------------------------------

def get_historical_cutoff(api_call: Callable) -> Dict[str, Any]:
    """
    GET /historical/cutoff — Get timestamps separating live vs historical data.
    """
    return api_call("GET", "/historical/cutoff")


def get_historical_markets(
    api_call: Callable,
    limit: int = 100,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """
    GET /historical/markets — List settled markets older than cutoff.
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor

    result = api_call("GET", "/historical/markets", params=params)
    if "error" in result:
        return result

    from plugins.kalshi_api.modules.markets import _parse_market
    markets = result.get("markets", [])
    return {
        "markets": [_parse_market(m) for m in markets],
        "cursor": result.get("cursor"),
        "count": len(markets),
    }


def get_historical_market_detail(
    api_call: Callable, ticker: str
) -> Dict[str, Any]:
    """
    GET /historical/markets/{ticker} — Single archived market.
    """
    if not ticker:
        return {"error": "Market ticker is required"}

    result = api_call("GET", f"/historical/markets/{ticker}")
    if "error" in result:
        return result

    from plugins.kalshi_api.modules.markets import _parse_market
    market = result.get("market", result)
    return _parse_market(market)


def get_historical_fills(
    api_call: Callable,
    ticker: Optional[str] = None,
    order_id: Optional[str] = None,
    limit: int = 100,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """
    GET /historical/fills — Fills from before historical cutoff.
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    if ticker:
        params["ticker"] = ticker
    if order_id:
        params["order_id"] = order_id

    result = api_call("GET", "/historical/fills", params=params)
    if "error" in result:
        return result

    fills = result.get("fills", [])
    return {
        "fills": [_parse_fill(f) for f in fills],
        "cursor": result.get("cursor"),
        "count": len(fills),
    }


def get_historical_orders(
    api_call: Callable,
    ticker: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 100,
    cursor: Optional[str] = None,
) -> Dict[str, Any]:
    """
    GET /historical/orders — Orders from before historical cutoff.
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    if ticker:
        params["ticker"] = ticker
    if status:
        params["status"] = status

    result = api_call("GET", "/historical/orders", params=params)
    if "error" in result:
        return result

    orders = result.get("orders", [])
    return {
        "orders": [_parse_order(o) for o in orders],
        "cursor": result.get("cursor"),
        "count": len(orders),
    }


# ---------------------------------------------------------------------------
# Phase 2B: Queue Position & Portfolio Summary
# ---------------------------------------------------------------------------

def get_queue_position(
    api_call: Callable,
    order_id: str,
) -> Dict[str, Any]:
    """
    GET /portfolio/orders/{order_id}/queue_position — Single order queue position.

    Returns:
        queue_position: int — Position in the matching queue
        queue_position_fp: str — Preceding shares count (fixed-point)
    """
    if not order_id:
        return {"error": "Order ID is required"}

    result = api_call("GET", f"/portfolio/orders/{order_id}/queue_position")
    if "error" in result:
        return result

    return {
        "order_id": order_id,
        "queue_position": result.get("queue_position", 0),
        "queue_position_fp": result.get("queue_position_fp", "0.00"),
    }


def get_queue_positions(
    api_call: Callable,
    market_tickers: Optional[str] = None,
    event_ticker: Optional[str] = None,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    GET /portfolio/orders/queue_positions — Batch queue positions.

    Args:
        market_tickers: Comma-separated market tickers to filter
        event_ticker: Event ticker to filter
        subaccount: 0=primary, 1-32
    """
    params: Dict[str, Any] = {}
    if market_tickers:
        params["market_tickers"] = market_tickers
    if event_ticker:
        params["event_ticker"] = event_ticker
    if subaccount is not None:
        params["subaccount"] = subaccount

    result = api_call("GET", "/portfolio/orders/queue_positions", params=params)
    if "error" in result:
        return result

    positions = result.get("queue_positions", [])
    return {
        "queue_positions": positions,
        "count": len(positions),
    }


def get_resting_order_value(api_call: Callable) -> Dict[str, Any]:
    """
    GET /portfolio/summary/total_resting_order_value — Total resting order value.

    Returns the total value of all resting (open) orders.
    """
    result = api_call("GET", "/portfolio/summary/total_resting_order_value")
    if "error" in result:
        return result

    return result


def get_orders(
    api_call: Callable,
    ticker: Optional[str] = None,
    event_ticker: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 100,
    cursor: Optional[str] = None,
    subaccount: Optional[int] = None,
) -> Dict[str, Any]:
    """
    GET /portfolio/orders — List orders.

    status: "resting" / "canceled" / "executed"
    """
    params: Dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    if ticker:
        params["ticker"] = ticker
    if event_ticker:
        params["event_ticker"] = event_ticker
    if status:
        params["status"] = status
    if subaccount is not None:
        params["subaccount"] = subaccount

    result = api_call("GET", "/portfolio/orders", params=params)
    if "error" in result:
        return result

    orders = result.get("orders", [])
    return {
        "orders": [_parse_order(o) for o in orders],
        "cursor": result.get("cursor"),
        "count": len(orders),
    }


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------

def _parse_position(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize a position object (dollar-denominated fields)."""
    return {
        "ticker": raw.get("ticker", ""),
        "position": raw.get("position", 0),
        "position_fp": raw.get("position_fp", "0.00"),
        "market_exposure_dollars": raw.get("market_exposure_dollars", "0.00"),
        "realized_pnl_dollars": raw.get("realized_pnl_dollars", "0.00"),
        "fees_paid_dollars": raw.get("fees_paid_dollars", "0.00"),
    }


def _parse_fill(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize a fill object."""
    return {
        "fill_id": raw.get("fill_id", ""),
        "order_id": raw.get("order_id", ""),
        "ticker": raw.get("ticker", ""),
        "side": raw.get("side", ""),
        "action": raw.get("action", ""),
        "count": raw.get("count_fp", str(raw.get("count", 0))),
        "yes_price": raw.get("yes_price_dollars", ""),
        "no_price": raw.get("no_price_dollars", ""),
        "is_taker": raw.get("is_taker", False),
        "fee_cost": raw.get("fee_cost", "0"),
        "created_time": raw.get("created_time", ""),
    }


def _parse_order(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize an order object (dollar-denominated fields)."""
    return {
        "order_id": raw.get("order_id", ""),
        "ticker": raw.get("ticker", ""),
        "status": raw.get("status", ""),
        "side": raw.get("side", ""),
        "action": raw.get("action", ""),
        "yes_price": raw.get("yes_price_dollars", ""),
        "no_price": raw.get("no_price_dollars", ""),
        "remaining_count": raw.get("remaining_count_fp", "0.00"),
        "initial_count": raw.get("initial_count_fp", "0.00"),
        "fill_count": raw.get("fill_count_fp", "0.00"),
        "time_in_force": raw.get("time_in_force", ""),
        "client_order_id": raw.get("client_order_id", ""),
        "order_group_id": raw.get("order_group_id", ""),
        "created_time": raw.get("created_time", ""),
        "last_update_time": raw.get("last_update_time", ""),
        "expiration_time": raw.get("expiration_time", ""),
        "subaccount": raw.get("subaccount_number", 0),
    }
