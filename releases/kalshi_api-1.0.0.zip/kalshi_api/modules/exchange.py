"""
Kalshi API — Exchange & Account module.

Handles exchange status, schedule, announcements, fee changes,
user data timestamps, and account API limits.
"""

from typing import Any, Callable, Dict, Optional
import logging

logger = logging.getLogger("kalshi_api.exchange")


def get_exchange_status(api_call: Callable) -> Dict[str, Any]:
    """
    GET /exchange/status — Exchange operational status.

    Returns:
        exchange_active: bool — False if exchange is fully down
        trading_active: bool — True if trading is permitted
        exchange_estimated_resume_time: str|None — Estimated resume (ISO 8601)
    """
    result = api_call("GET", "/exchange/status")
    if "error" in result:
        return result

    return {
        "exchange_active": result.get("exchange_active", False),
        "trading_active": result.get("trading_active", False),
        "exchange_estimated_resume_time": result.get("exchange_estimated_resume_time"),
    }


def get_exchange_schedule(api_call: Callable) -> Dict[str, Any]:
    """
    GET /exchange/schedule — Trading hours and maintenance windows.

    Returns:
        schedule.standard_hours: Weekly trading schedule (ET timezone)
        schedule.maintenance_windows: Planned downtime windows
    """
    result = api_call("GET", "/exchange/schedule")
    if "error" in result:
        return result

    schedule = result.get("schedule", {})
    return {
        "standard_hours": schedule.get("standard_hours", []),
        "maintenance_windows": schedule.get("maintenance_windows", []),
    }


def get_exchange_announcements(api_call: Callable) -> Dict[str, Any]:
    """
    GET /exchange/announcements — Exchange-wide announcements.

    Returns list of announcements with type (info/warning/error),
    message, delivery_time, and status (active/inactive).
    """
    result = api_call("GET", "/exchange/announcements")
    if "error" in result:
        return result

    announcements = result.get("announcements", [])
    return {
        "announcements": [
            {
                "type": a.get("type", ""),
                "message": a.get("message", ""),
                "delivery_time": a.get("delivery_time", ""),
                "status": a.get("status", ""),
            }
            for a in announcements
        ],
        "count": len(announcements),
    }


def get_fee_changes(
    api_call: Callable,
    series_ticker: Optional[str] = None,
    show_historical: bool = False,
) -> Dict[str, Any]:
    """
    GET /series/fee_changes — Series fee change records.

    Args:
        series_ticker: Filter by series ticker (optional)
        show_historical: Include past fee changes (default False)
    """
    params: Dict[str, Any] = {}
    if series_ticker:
        params["series_ticker"] = series_ticker
    if show_historical:
        params["show_historical"] = "true"

    result = api_call("GET", "/series/fee_changes", params=params)
    if "error" in result:
        return result

    return {
        "fee_changes": result.get("fee_changes", []),
    }


def get_user_data_timestamp(api_call: Callable) -> Dict[str, Any]:
    """
    GET /exchange/user_data_timestamp — Last validation time for user data.

    Indicates when data from GetBalance, GetOrders, GetFills,
    GetPositions was last validated by the exchange.
    """
    result = api_call("GET", "/exchange/user_data_timestamp")
    if "error" in result:
        return result

    return {
        "as_of_time": result.get("as_of_time", ""),
    }


def get_account_limits(api_call: Callable) -> Dict[str, Any]:
    """
    GET /account/limits — API tier rate limits for authenticated user.

    Returns API tier information and rate limit thresholds.
    """
    result = api_call("GET", "/account/limits")
    if "error" in result:
        return result

    return result
