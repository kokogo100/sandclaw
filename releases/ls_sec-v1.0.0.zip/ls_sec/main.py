"""
LS Securities (LS증권) Plugin
==============================
Korean Stock Trading via LS Securities Open API (OAuth2 + REST)

Domain: https://openapi.ls-sec.co.kr:8080
Auth: OAuth2 — App Key + App Secret Key → Bearer token (24h)
TRs: t1102 (현재가), t0424 (잔고), CSPAT00601 (주문), CSPAT00701 (정정), CSPAT00801 (취소)

Reference: docs/ls증권정보/ (90+ API documents)
"""
import os
import logging
import asyncio
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta

import httpx

from core.plugin_api import BrokerPlugin, PluginMetadata
from core.models import AccountInfo, PortfolioItem
from core.key_manager import KeyManager

logger = logging.getLogger("LSSecPlugin")

BASE_URL = "https://openapi.ls-sec.co.kr:8080"


class LSSecPlugin(BrokerPlugin):
    """
    LS Securities Plugin — Korean stock trading via OAuth2 REST API

    Follows the exact BrokerPlugin ABC from core/plugin_api.py.
    Uses KeyManager for credential storage (connect() takes NO parameters).
    """

    def __init__(self):
        self._access_token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None
        self._connected = False
        self._app_key: str = ""
        self._app_secret: str = ""

    # =========================================================================
    # [REQUIRED] Metadata & Connection
    # =========================================================================

    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            id="ls_sec",
            name="LS Securities",
            version="1.0.0",
            author="SandClaw Team",
            description="LS증권 Open API — 한국 주식 현재가, 차트, 계좌, 주문",
            plugin_type="api",
            region="KR",
            asset_classes=["STOCK"],
            symbol_example="005930",
            markets=["KRX"]
        )

    def connect(self) -> bool:
        """
        Connect to LS Securities API using KeyManager.
        NO parameters — loads keys from secure vault.

        Keys expected:
        - api_key: LS증권 App Key
        - secret_key: LS증권 App Secret Key
        """
        try:
            keys = KeyManager.get_keys('ls_sec')

            self._app_key = keys.get('api_key', '')
            self._app_secret = keys.get('secret_key', '')

            if not self._app_key or not self._app_secret:
                logger.warning("[LS증권] Missing keys in KeyManager")
                self._connected = False
                return False

            # Request OAuth2 token
            success = self._refresh_token()
            if not success:
                self._connected = False
                return False

            logger.info("[LS증권] Connected successfully (Bearer token acquired)")
            self._connected = True
            return True

        except Exception as e:
            logger.error(f"[LS증권] Connection failed: {e}")
            self._connected = False
            return False

    def _refresh_token(self) -> bool:
        """Request OAuth2 Bearer token (24h validity)"""
        try:
            resp = httpx.post(
                f"{BASE_URL}/oauth2/token",
                data={
                    "grant_type": "client_credentials",
                    "appkey": self._app_key,
                    "appsecretkey": self._app_secret,
                    "scope": "oob",
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=10.0,
            )

            if resp.status_code != 200:
                logger.error(f"[LS증권] Token request failed: {resp.status_code} {resp.text}")
                return False

            data = resp.json()
            self._access_token = data.get("access_token")
            expires_in = int(data.get("expires_in", 86400))
            self._token_expires_at = datetime.now() + timedelta(seconds=expires_in - 300)  # 5min buffer

            if not self._access_token:
                logger.error("[LS증권] No access_token in response")
                return False

            logger.info(f"[LS증권] Token acquired (expires in {expires_in}s)")
            return True

        except Exception as e:
            logger.error(f"[LS증권] Token request error: {e}")
            return False

    def _ensure_token(self) -> bool:
        """Auto-refresh token if expired"""
        if not self._access_token or not self._token_expires_at:
            return False
        if datetime.now() >= self._token_expires_at:
            logger.info("[LS증권] Token expired, refreshing...")
            return self._refresh_token()
        return True

    def _make_headers(self, tr_cd: str, tr_cont: str = "N") -> Dict[str, str]:
        """Build standard API headers"""
        return {
            "content-type": "application/json; charset=utf-8",
            "authorization": f"Bearer {self._access_token}",
            "tr_cd": tr_cd,
            "tr_cont": tr_cont,
        }

    def _api_call(self, path: str, tr_cd: str, body: Dict[str, Any],
                  tr_cont: str = "N") -> Dict[str, Any]:
        """Generic synchronous API call with auto-token-refresh"""
        if not self._ensure_token():
            return {"error": "Token expired and refresh failed"}

        try:
            resp = httpx.post(
                f"{BASE_URL}{path}",
                headers=self._make_headers(tr_cd, tr_cont),
                json=body,
                timeout=15.0,
            )

            if resp.status_code != 200:
                return {"error": f"HTTP {resp.status_code}: {resp.text[:200]}"}

            data = resp.json()

            # Check for API-level error
            rsp_cd = data.get("rsp_cd", "")
            rsp_msg = data.get("rsp_msg", "")
            if rsp_cd and not rsp_cd.startswith("0"):
                return {"error": f"[{rsp_cd}] {rsp_msg}"}

            return data

        except httpx.TimeoutException:
            return {"error": "API request timed out"}
        except Exception as e:
            return {"error": str(e)}

    @property
    def is_connected(self) -> bool:
        return self._connected

    def check_health(self) -> bool:
        """Verify connection is alive by checking token validity"""
        if not self._connected:
            return False
        return self._ensure_token()

    # =========================================================================
    # [REQUIRED] Account & Portfolio
    # =========================================================================

    def get_account_info(self) -> AccountInfo:
        """Get account balance (CSPAQ12200 TR)"""
        if not self._connected:
            return AccountInfo(
                total_balance=0, cash_balance=0,
                unrealized_pnl=0, pnl_rate=0,
                currency="KRW", total_invested=0
            )

        try:
            data = self._api_call(
                "/stock/accno",
                "CSPAQ12200",
                {"CSPAQ12200InBlock1": {"BalCreTp": "0"}}
            )

            if "error" in data:
                logger.error(f"[LS증권] get_account_info error: {data['error']}")
                return AccountInfo(
                    total_balance=0, cash_balance=0,
                    unrealized_pnl=0, pnl_rate=0,
                    currency="KRW", total_invested=0
                )

            block = data.get("CSPAQ12200OutBlock2", {})

            total_assets = float(block.get("DpsastTotamt", 0))
            cash = float(block.get("MnyOrdAbleAmt", 0))
            eval_amt = float(block.get("BalEvalAmt", 0))
            pnl_rate = float(block.get("PnlRat", 0))
            invested = float(block.get("InvstOrgAmt", 0))

            return AccountInfo(
                total_balance=total_assets,
                cash_balance=cash,
                unrealized_pnl=total_assets - invested - cash if invested > 0 else 0,
                pnl_rate=pnl_rate,
                currency="KRW",
                total_invested=invested
            )

        except Exception as e:
            logger.error(f"[LS증권] get_account_info failed: {e}")
            return AccountInfo(
                total_balance=0, cash_balance=0,
                unrealized_pnl=0, pnl_rate=0,
                currency="KRW", total_invested=0
            )

    def get_portfolio(self) -> List[PortfolioItem]:
        """Get stock holdings (t0424 TR — 주식잔고2)"""
        if not self._connected:
            return []

        try:
            data = self._api_call(
                "/stock/accno",
                "t0424",
                {"t0424InBlock": {
                    "prcgb": "", "chegb": "", "dangb": "",
                    "charge": "", "cts_expcode": ""
                }}
            )

            if "error" in data:
                logger.error(f"[LS증권] get_portfolio error: {data['error']}")
                return []

            holdings = data.get("t0424OutBlock1", [])
            if not isinstance(holdings, list):
                holdings = [holdings] if holdings else []

            portfolio = []
            for item in holdings:
                try:
                    portfolio.append(PortfolioItem(
                        symbol=str(item.get("expcode", "")),
                        name=str(item.get("hname", "")),
                        current_price=float(item.get("price", 0)),
                        avg_price=float(item.get("pamt", 0)),
                        quantity=float(item.get("janqty", 0)),
                        pnl_rate=float(item.get("sunikrt", 0)),
                        pnl_amount=float(item.get("dtsunik", 0)),
                        market_value=float(item.get("appamt", 0)),
                        invested_amount=float(item.get("mamt", 0)),
                    ))
                except Exception as e:
                    logger.warning(f"[LS증권] Failed to parse holding: {e}")

            return portfolio

        except Exception as e:
            logger.error(f"[LS증권] get_portfolio failed: {e}")
            return []

    # =========================================================================
    # [REQUIRED] Trading
    # =========================================================================

    def buy_order(self, symbol: str, quantity: float) -> Dict[str, Any]:
        """Buy stock at market price (CSPAT00601 TR, BnsTpCode=2)"""
        return self._place_order(symbol, quantity, buy_sell="2", price_type="03", price=0)

    def sell_order(self, symbol: str, quantity: float) -> Dict[str, Any]:
        """Sell stock at market price (CSPAT00601 TR, BnsTpCode=1)"""
        return self._place_order(symbol, quantity, buy_sell="1", price_type="03", price=0)

    def _place_order(self, symbol: str, quantity: float,
                     buy_sell: str, price_type: str, price: float) -> Dict[str, Any]:
        """
        Internal order execution.

        Args:
            symbol: 6-digit stock code (e.g., "005930")
            quantity: Number of shares
            buy_sell: "1"=Sell, "2"=Buy
            price_type: "00"=Limit, "03"=Market
            price: Order price (0 for market orders)
        """
        if not self._connected:
            return {"error": "Not connected"}

        # LS증권 requires "A" prefix for stock code in order API
        isu_no = f"A{symbol}" if not symbol.startswith("A") else symbol

        body = {
            "CSPAT00601InBlock1": {
                "IsuNo": isu_no,
                "OrdQty": int(quantity),
                "OrdPrc": float(price),
                "BnsTpCode": buy_sell,
                "OrdprcPtnCode": price_type,
                "MgntrnCode": "000",
                "LoanDt": "",
                "OrdCndiTpCode": "0",
                "MbrNo": "KRX",
            }
        }

        data = self._api_call("/stock/order", "CSPAT00601", body)

        if "error" in data:
            return {"error": data["error"]}

        out2 = data.get("CSPAT00601OutBlock2", {})
        order_no = out2.get("OrdNo", "")
        order_time = out2.get("OrdTime", "")
        isu_nm = out2.get("IsuNm", "")

        action = "매수" if buy_sell == "2" else "매도"
        return {
            "success": True,
            "order_id": str(order_no),
            "message": f"{isu_nm} {action} 주문 완료 (주문번호: {order_no}, 시간: {order_time})"
        }

    def cancel_order(self, order_id: str) -> bool:
        """Cancel an open order (CSPAT00801 TR)"""
        # Note: cancel requires IsuNo and OrdQty which we don't have from just order_id
        # This is a simplified version — full implementation would need order tracking
        logger.warning(f"[LS증권] cancel_order({order_id}): requires additional info (IsuNo, OrdQty)")
        return False

    def get_order_status(self, **kwargs) -> Dict[str, Any]:
        """Get order status — placeholder for ABC compatibility"""
        return {"error": "Use ls_sec_get_order_status tool for detailed status"}

    # =========================================================================
    # [REQUIRED] Price Data
    # =========================================================================

    def get_price(self, symbol: str) -> Dict[str, Any]:
        """Get current price (t1102 TR)"""
        if not self._connected:
            return {"symbol": symbol, "price": 0.0}

        data = self._api_call(
            "/stock/market-data",
            "t1102",
            {"t1102InBlock": {"shcode": symbol}}
        )

        if "error" in data:
            return {"symbol": symbol, "price": 0.0, "error": data["error"]}

        block = data.get("t1102OutBlock", {})

        return {
            "symbol": symbol,
            "name": block.get("hname", ""),
            "price": float(block.get("price", 0)),
            "change": float(block.get("change", 0)),
            "change_rate": float(block.get("diff", 0)),
            "volume": int(block.get("volume", 0)),
            "open": float(block.get("open", 0)),
            "high": float(block.get("high", 0)),
            "low": float(block.get("low", 0)),
            "per": float(block.get("per", 0)),
            "pbr": float(block.get("pbrx", 0)),
            "market_cap": float(block.get("total", 0)),
            "market": block.get("janginfo", ""),
        }

    def get_current_prices(self, symbols: List[str]) -> Dict[str, float]:
        """Batch price lookup (calls t1102 for each — rate limit: 3/sec)"""
        if not self._connected:
            return {s: 0.0 for s in symbols}

        results = {}
        for i, symbol in enumerate(symbols):
            try:
                data = self.get_price(symbol)
                results[symbol] = data.get("price", 0.0)
            except Exception as e:
                logger.warning(f"[LS증권] Price fetch failed for {symbol}: {e}")
                results[symbol] = 0.0

            # Rate limit: 3 req/sec for t1102
            if i < len(symbols) - 1:
                import time
                time.sleep(0.35)

        return results

    async def get_ohlcv(self, symbol: str, interval: str = "day",
                        count: int = 200) -> Any:
        """Get OHLCV candle data (async wrapper)"""
        try:
            result = await asyncio.to_thread(
                self._get_ohlcv_sync, symbol, interval, count
            )
            return result
        except Exception as e:
            logger.error(f"[LS증권] get_ohlcv failed for {symbol}: {e}")
            return None

    def _get_ohlcv_sync(self, symbol: str, interval: str = "day",
                        count: int = 200) -> Any:
        """Synchronous OHLCV — t8410 (주식차트) or similar"""
        # Simplified: return price data as dict list (full chart TR would need t8410/t8412)
        price_data = self.get_price(symbol)
        if "error" in price_data:
            return None

        # Return single-candle data as minimal response
        return [{
            "date": datetime.now().strftime("%Y-%m-%d"),
            "open": price_data.get("open", 0),
            "high": price_data.get("high", 0),
            "low": price_data.get("low", 0),
            "close": price_data.get("price", 0),
            "volume": price_data.get("volume", 0),
        }]

    def get_all_tickers(self) -> List[str]:
        """Get all tradable tickers — returns common KRX tickers"""
        # LS증권 doesn't have a simple "list all tickers" TR
        # Return well-known tickers as default
        return [
            "005930", "000660", "035420", "035720", "051910",
            "006400", "068270", "028260", "105560", "055550",
            "066570", "003670", "034730", "012330", "096770",
            "015760", "017670", "030200", "032830", "086790",
        ]

    # =========================================================================
    # [REQUIRED] AI Tool Calling
    # =========================================================================

    def get_tools(self) -> List[Dict[str, Any]]:
        """Return 5 MVP tool definitions for AI Commander"""
        return [
            {
                "type": "function",
                "function": {
                    "name": "ls_sec_get_stock_price",
                    "description": (
                        "[USE THIS WHEN] user asks for Korean stock price, 현재가, 시세, stock info "
                        "[DO NOT USE THIS WHEN] user asks for US stocks (use Alpaca) or crypto (use Upbit). "
                        "Get current stock price from LS Securities (t1102 TR). "
                        "Returns: price, change, volume, PER, PBR, market cap."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "shcode": {
                                "type": "string",
                                "description": "6-digit Korean stock code (e.g., '005930' for Samsung, '000660' for SK Hynix)"
                            }
                        },
                        "required": ["shcode"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "ls_sec_get_stock_chart",
                    "description": (
                        "[USE THIS WHEN] user asks for Korean stock chart, price history, 차트, 일봉 "
                        "[DO NOT USE THIS WHEN] user asks for US stock charts. "
                        "Get OHLCV chart data for a Korean stock."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "shcode": {
                                "type": "string",
                                "description": "6-digit Korean stock code"
                            },
                            "period": {
                                "type": "string",
                                "enum": ["day", "week", "month"],
                                "description": "Chart period (default: day)"
                            },
                            "count": {
                                "type": "integer",
                                "description": "Number of candles (default: 20, max: 200)"
                            }
                        },
                        "required": ["shcode"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "ls_sec_get_account_balance",
                    "description": (
                        "[USE THIS WHEN] user asks for LS증권 account balance, 잔고, 예수금, holdings "
                        "[DO NOT USE THIS WHEN] user asks for Alpaca/Upbit balance. "
                        "Get account balance and stock holdings from LS Securities."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {},
                        "required": []
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "ls_sec_place_order",
                    "description": (
                        "[USE THIS WHEN] user wants to buy/sell Korean stocks via LS증권 "
                        "[DO NOT USE THIS WHEN] user wants to trade US stocks or crypto. "
                        "Place a buy or sell order on LS Securities (CSPAT00601 TR)."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "shcode": {
                                "type": "string",
                                "description": "6-digit Korean stock code (e.g., '005930')"
                            },
                            "quantity": {
                                "type": "integer",
                                "description": "Number of shares to order"
                            },
                            "side": {
                                "type": "string",
                                "enum": ["buy", "sell"],
                                "description": "Order side: buy or sell"
                            },
                            "order_type": {
                                "type": "string",
                                "enum": ["market", "limit"],
                                "description": "Order type (default: market)"
                            },
                            "price": {
                                "type": "number",
                                "description": "Limit price (required for limit orders, ignored for market)"
                            }
                        },
                        "required": ["shcode", "quantity", "side"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "ls_sec_get_order_status",
                    "description": (
                        "[USE THIS WHEN] user asks about order status, 체결, 미체결, pending orders "
                        "Get order execution status from LS Securities."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {},
                        "required": []
                    }
                }
            },
        ]

    def execute_tool(self, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Execute AI-requested tool"""
        handlers = {
            "ls_sec_get_stock_price": self._tool_get_stock_price,
            "ls_sec_get_stock_chart": self._tool_get_stock_chart,
            "ls_sec_get_account_balance": self._tool_get_account_balance,
            "ls_sec_place_order": self._tool_place_order,
            "ls_sec_get_order_status": self._tool_get_order_status,
        }

        handler = handlers.get(tool_name)
        if not handler:
            return {"error": f"Unknown tool: {tool_name}"}

        try:
            return handler(args)
        except Exception as e:
            logger.error(f"[LS증권] execute_tool({tool_name}) failed: {e}")
            return {"error": str(e)}

    # =========================================================================
    # Tool Handlers
    # =========================================================================

    def _tool_get_stock_price(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handler: ls_sec_get_stock_price"""
        shcode = args.get("shcode", "")
        if not shcode:
            return {"error": "shcode (종목코드) is required"}

        data = self._api_call(
            "/stock/market-data",
            "t1102",
            {"t1102InBlock": {"shcode": shcode}}
        )

        if "error" in data:
            return data

        block = data.get("t1102OutBlock", {})

        # Sign interpretation: 1=상한, 2=상승, 3=보합, 4=하한, 5=하락
        sign = str(block.get("sign", "3"))
        sign_map = {"1": "▲ 상한", "2": "▲ 상승", "3": "- 보합", "4": "▼ 하한", "5": "▼ 하락"}
        sign_text = sign_map.get(sign, sign)

        return {
            "symbol": shcode,
            "name": block.get("hname", ""),
            "price": block.get("price", 0),
            "sign": sign_text,
            "change": block.get("change", 0),
            "change_rate": f"{block.get('diff', 0)}%",
            "volume": block.get("volume", 0),
            "open": block.get("open", 0),
            "high": block.get("high", 0),
            "low": block.get("low", 0),
            "per": block.get("per", 0),
            "pbr": block.get("pbrx", 0),
            "market_cap_billion": block.get("total", 0),
            "market": block.get("janginfo", ""),
            "high_52w": block.get("high52w", 0),
            "low_52w": block.get("low52w", 0),
        }

    def _tool_get_stock_chart(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handler: ls_sec_get_stock_chart — returns current price data"""
        shcode = args.get("shcode", "")
        if not shcode:
            return {"error": "shcode (종목코드) is required"}

        # For MVP, return current price data as single-candle
        # Full implementation would use t8410 (일봉), t8411 (주봉), t8412 (월봉)
        price_data = self._tool_get_stock_price({"shcode": shcode})
        if "error" in price_data:
            return price_data

        return {
            "symbol": shcode,
            "name": price_data.get("name", ""),
            "period": args.get("period", "day"),
            "data": [{
                "date": datetime.now().strftime("%Y-%m-%d"),
                "open": price_data.get("open", 0),
                "high": price_data.get("high", 0),
                "low": price_data.get("low", 0),
                "close": price_data.get("price", 0),
                "volume": price_data.get("volume", 0),
            }],
            "note": "MVP: 현재 가격 데이터 반환. 향후 t8410/t8411/t8412 TR로 히스토리 차트 구현 예정."
        }

    def _tool_get_account_balance(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handler: ls_sec_get_account_balance"""
        account = self.get_account_info()
        portfolio = self.get_portfolio()

        holdings = []
        for item in portfolio:
            holdings.append({
                "symbol": item.symbol,
                "name": item.name,
                "quantity": item.quantity,
                "avg_price": item.avg_price,
                "current_price": item.current_price,
                "pnl_rate": f"{item.pnl_rate}%",
                "pnl_amount": item.pnl_amount,
                "market_value": item.market_value,
            })

        return {
            "account": {
                "total_balance": account.total_balance,
                "cash_balance": account.cash_balance,
                "unrealized_pnl": account.unrealized_pnl,
                "pnl_rate": f"{account.pnl_rate}%",
                "currency": account.currency,
            },
            "holdings_count": len(holdings),
            "holdings": holdings,
        }

    def _tool_place_order(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handler: ls_sec_place_order"""
        shcode = args.get("shcode", "")
        quantity = args.get("quantity", 0)
        side = args.get("side", "buy")
        order_type = args.get("order_type", "market")
        price = args.get("price", 0)

        if not shcode:
            return {"error": "shcode (종목코드) is required"}
        if quantity <= 0:
            return {"error": "quantity must be > 0"}

        buy_sell = "2" if side == "buy" else "1"
        price_type = "03" if order_type == "market" else "00"

        return self._place_order(shcode, quantity, buy_sell, price_type, price)

    def _tool_get_order_status(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handler: ls_sec_get_order_status — placeholder for MVP"""
        # Full implementation would use t0425 (체결/미체결 조회)
        return {
            "message": "주문 상태 조회 기능은 향후 업데이트에서 구현 예정입니다.",
            "note": "MVP: t0425 TR 구현 예정"
        }

    # =========================================================================
    # [REQUIRED] AI System Prompt
    # =========================================================================

    def get_ai_system_prompt(self) -> str:
        """Return AI instruction manual for LS Securities"""
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            prompt_path = os.path.join(current_dir, "system_prompt.txt")

            if os.path.exists(prompt_path):
                with open(prompt_path, "r", encoding="utf-8") as f:
                    return f.read()
        except Exception:
            pass

        # Inline fallback prompt
        return (
            "## LS Securities (LS증권) Plugin\n"
            "You have access to LS Securities API for Korean stock trading.\n\n"
            "### Available Tools:\n"
            "1. `ls_sec_get_stock_price` — 한국 주식 현재가 조회 (종목코드 6자리, 예: 005930=삼성전자)\n"
            "2. `ls_sec_get_stock_chart` — 주식 차트 데이터 (일/주/월)\n"
            "3. `ls_sec_get_account_balance` — 계좌 잔고 + 보유 종목\n"
            "4. `ls_sec_place_order` — 매수/매도 주문\n"
            "5. `ls_sec_get_order_status` — 체결/미체결 조회\n\n"
            "### Common Stock Codes:\n"
            "- 005930 = 삼성전자, 000660 = SK하이닉스, 035420 = NAVER\n"
            "- 035720 = 카카오, 051910 = LG화학, 006400 = 삼성SDI\n"
            "- 068270 = 셀트리온, 028260 = 삼성물산, 105560 = KB금융\n\n"
            "### Order Rules:\n"
            "- Always confirm with user before placing orders\n"
            "- Market orders: order_type='market', price not needed\n"
            "- Limit orders: order_type='limit', price required\n"
        )

    # =========================================================================
    # [OPTIONAL] Capabilities
    # =========================================================================

    def get_capabilities(self) -> Dict[str, Any]:
        return {
            "has_websocket": False,  # MVP: REST only (WebSocket 추후)
            "has_search": True,
            "supports_auto_trading": True,
            "supports_condition_search": False,
            "supports_browser_automation": False,
        }

    def get_supported_filters(self) -> List[str]:
        return []

    @property
    def batch_size(self) -> int:
        return 20  # Conservative: t1102 rate limit 3/sec

    @property
    def batch_delay(self) -> float:
        return 0.35  # 3 req/sec = 333ms between calls

    def disconnect(self) -> None:
        """Disconnect from LS Securities"""
        self._access_token = None
        self._token_expires_at = None
        self._connected = False
        logger.info("[LS증권] Disconnected")

    def search_symbol(self, query: str) -> List[Dict[str, Any]]:
        """Search for stock symbol by name — simplified version"""
        # Full implementation would use t1101 or similar TR
        # For MVP, return common matches
        common = {
            "삼성전자": "005930", "삼성": "005930",
            "SK하이닉스": "000660", "하이닉스": "000660",
            "NAVER": "035420", "네이버": "035420",
            "카카오": "035720",
            "LG화학": "051910",
            "삼성SDI": "006400",
            "셀트리온": "068270",
            "현대차": "005380",
            "기아": "000270",
            "포스코홀딩스": "005490",
        }

        results = []
        q = query.strip().upper()
        for name, code in common.items():
            if q in name.upper() or q in code:
                results.append({"symbol": code, "name": name})

        return results
